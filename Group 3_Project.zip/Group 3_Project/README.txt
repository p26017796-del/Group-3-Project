# CornerShop Inventory Management System

This folder contains a separately modified version of the classroom project. The original PyCharm project was not overwritten. Existing database records are retained. Startup migrations add the required tables, shelf locations, and opening stock records without inventing historical stock movements.

## Running the Application

Open this folder in PyCharm, select a Python interpreter with the required dependencies, and run `app.py`. The default address is http://127.0.0.1:5000. If another project is using that port, stop it first or run `python -m flask --app app run --port 5051`.

```sh
python -m pip install -r requirements.txt
python app.py
```

The administrator retains the existing login credentials. Administrators, Warehouse Staff, and Sales Staff use the same sign-in page and are directed to the workspace for their role. The administrator registers staff through the Staff page; staff then sign in using their assigned accounts. No new staff accounts or fictional transactions are preset.

An alternative local preview address is http://127.0.0.1:5051 when the server is started on that port. The server must remain running to access it.

## Implemented Features

- A light blue, purple, and orange interface with consistent navigation, inventory cards, stock-health charts, and product search and filtering. The overview refreshes data every 30 seconds, pausing while filters are being entered.
- Server-side permissions for three roles, shared sign-in, profiles, password updates, and staff account management. New and updated staff passwords are hashed; legacy password storage is upgraded after a successful staff login.
- Stock movements for opening balances, manual stock-in, internal stock-out, purchases, sales, dispatch, cancellations, returns, stock adjustments, and whole-product shelf transfers. Records include the operator, time, quantity, and balance.
- Purchase requests followed by administrator approval or rejection and warehouse receiving. Records include the supplier, quantity, unit cost, expected date, delivered quantity, and damaged quantity. Only usable units are added to stock.
- Sales orders progress through Pending, Confirmed, Dispatched, and Completed states, with cancellation available in permitted states.
- Order confirmation combines quantities for repeated products, checks and deducts stock within one transaction, and records one payment. Controls prevent overselling during concurrent confirmation and repeated stock deductions for duplicate confirmation attempts.
- Cancelling a confirmed, undispatched order restores stock and marks its payment as refunded. Dispatched or completed orders support returns and refund records, with cumulative returns limited to the quantity sold.
- Warehouse staff can submit adjustment requests for damaged, expired, or missing stock. Before approval, the administrator workflow checks both quantity and stock-movement version to detect outdated counts.
- System notifications for low stock, out-of-stock products, pending approvals, purchases, and order changes. Read status is stored separately for each user.
- Filtered inventory reports and daily, weekly, monthly, or custom-date reports for stock movements, purchases, sales, supplier performance, and fast- and slow-moving products. PDF and CSV exports are supported. CSV files can be opened in Excel; they are not native XLSX workbooks.
- Supplier performance includes on-time delivery rate, usable-goods rate, and received value. Inventory trends use net sales after cancellations and returns.
- Local machine-learning inventory questions and answers, product category suggestions, and separate rule-based replenishment recommendations.

## Suggested Demonstration Sequence

1. Register Warehouse Staff and Sales Staff accounts as the administrator, then add suppliers and products.
2. Create a purchase request as warehouse staff, approve it as the administrator, and record delivered and damaged quantities. Review stock movements and shelf locations.
3. Create and confirm a sales order. Check that stock decreases and one payment is recorded. Mark the order as dispatched through the warehouse workflow, then completed through the sales workflow.
4. Test order cancellation, customer returns, and insufficient-stock messages.
5. Submit a stock count and approve it. If stock changes before approval, confirm that the system blocks the outdated count from overwriting current inventory.
6. Review notifications for the three roles, customer history, and reports for different date ranges. Export a PDF report.
7. Try category suggestions in the product form and enter a short English question containing an exact product name in the Inventory Assistant.

## Operational Rules and Limitations

- Confirming an order represents manual confirmation that payment has been received. The system records payments and refunds but does not connect to a bank or payment gateway or transfer money.
- Stock is deducted when an order is confirmed, not again when it is dispatched.
- Receiving closes the purchase record. Any undelivered quantity requires a new purchase request; multiple partial receipts against one purchase are not supported.
- Each product has one current shelf location. A transfer moves the whole product record rather than distributing quantities across multiple warehouses or storage locations.
- The return workflow is intended for resalable goods. Damaged returns require a separate damaged-stock adjustment after the return is recorded.
- Timestamps and report dates use UTC. Sales reports filter by order creation date, while supplier performance filters by receiving date. Sales totals include subsequent refunds for selected orders, so these reports are not cash-flow reports filtered by payment date.
- Inventory value uses current selling prices and does not represent purchase cost or profit. Historical stock movements cannot be reconstructed from the original database.
- Available stock includes all products with positive quantities. Low stock means `0 < quantity <= reorder level`; out of stock means `quantity <= 0`.
- Original products, categories, and prices were retained rather than automatically replaced with fictional convenience-store examples. The earlier database check found no negative-stock products or duplicate payment groups requiring historical cleanup.

## Scope of the Local AI

`local_ai.py` uses small multinomial Naive Bayes classifiers trained on synthetic English examples. The assistant identifies a query intent and then retrieves actual inventory data. The category model suggests a category for manual review before saving.

These models are not ChatGPT or generative large language models. They do not require an API key or send inventory data to an external service. They are intended for short English inventory questions. Model scores are not calibrated accuracy measurements; the training data and measured accuracy could be improved further. Assessment of these features should follow the course's AI requirements.

Replenishment recommendations use an explicit formula: the target is the larger of twice the reorder level and 14 days of demand based on average daily sales over the previous 30 days, minus current stock. This is rule-based replenishment rather than AI demand forecasting. It does not account for seasonality, outstanding purchases, or supplier lead times.

## Validation

```sh
python -m compileall -q app.py access.py operations.py local_ai.py chatbot.py database.py
python -m unittest discover -s tests -v
```

The earlier validation record covered 27 automated tests using isolated temporary databases. It included anonymous and incorrect-role access, CSRF protection, prevention of deletion through GET/HEAD requests, immediate enforcement of role changes, stock updates, repeated products, concurrent overselling prevention, transaction rollback, single-payment recording, order workflows, cancellation, return limits, purchase approval, duplicate receiving prevention, outdated-count protection, stock movements, shelf locations, date filtering, PDF/CSV exports, per-user notifications, passwords, product editing, and local model endpoints. Run the current test suite to obtain its latest test count and results.

Earlier browser checks covered shared sign-in, the updated overview, purchasing, and mobile-width layouts. These checks did not constitute public deployment testing, external payment testing, or a complete independent security audit. Individual reports, contribution records, and VIVA materials are prepared separately.

## Code Structure and Configuration

- `app.py` retains the original routes and pages and installs the newer business handlers and access controls during application setup.
- `access.py` applies authentication, role, and CSRF checks across endpoints. `operations.py` installs transactional business handlers that replace older transaction functions. `local_ai.py` installs local model endpoints.
- `database.py` uses `inventory.db` beside the application to avoid opening the wrong database when the working directory changes.
- `CORNER_SHOP_ADMIN_EMAIL` and `CORNER_SHOP_ADMIN_PASSWORD` configure administrator credentials. `CORNER_SHOP_SECRET` configures the session secret. If no secret is configured, the application creates a local `.session_key` on first startup. Do not include this secret file in distributed ZIP packages.
- The original and modified databases are separate copies and do not synchronise automatically. Back up data before replacing a database, and do not overwrite the database of a running application with an older copy.
