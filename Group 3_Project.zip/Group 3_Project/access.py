"""One authenticated identity, role policy and CSRF validation for every route."""
import hashlib
import hmac
import os
from pathlib import Path
import re
import secrets
from flask import request, session, redirect, url_for, render_template, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
import database
from operations import read, transaction, notify


def stamp(password):
    return hashlib.sha256(password.encode()).hexdigest()


def check_password(stored, supplied):
    if stored.startswith(('scrypt:','pbkdf2:')):
        return check_password_hash(stored,supplied)
    return hmac.compare_digest(stored,supplied)


def install(app, admin_email, admin_password):
    configured=os.environ.get('CORNER_SHOP_SECRET')
    key_path=Path(__file__).with_name('.session_key')
    if not configured:
        try:
            with key_path.open('x') as f: f.write(secrets.token_hex(32))
            key_path.chmod(0o600)
        except FileExistsError: pass
        configured=key_path.read_text().strip()
    app.secret_key=configured
    app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',CSRF_ENABLED=True)
    admin_email=os.environ.get('CORNER_SHOP_ADMIN_EMAIL',admin_email)
    admin_password=os.environ.get('CORNER_SHOP_ADMIN_PASSWORD',admin_password)

    def administrator():
        # Configured credentials bootstrap the account until its first profile save.
        saved = read("SELECT * FROM users WHERE role='Admin' ORDER BY id LIMIT 1", one=True)
        return dict(saved) if saved else dict(id=None, name='Administrator', email=admin_email,
                                             password=admin_password, role='Admin')

    def csrf_token():
        if '_csrf' not in session: session['_csrf']=secrets.token_hex(24)
        return session['_csrf']
    app.jinja_env.globals['csrf_token']=csrf_token

    public={'login','warehouse_login','sales_login','static'}
    everyone={'logout','warehouse_logout','profile','chatbot.chatbot_page','chatbot.ask_chatbot','notifications',
              'order_workflow','sales_orders','view_sales_order','sales_order_pdf','activity_reports','export_activity'}
    admin={'product_category_suggestion','dashboard','staff_directory','register_staff','edit_staff','delete_staff','manage_products','add_product','edit_product','delete_product',
           'admin_stock_adjustment_requests','approve_stock_adjustment','reject_stock_adjustment'}
    warehouse={'warehouse_dashboard','warehouse_profile','warehouse_change_password','stock_adjustment_request','history'}
    operations={'manage_inventory','manage_suppliers','add_supplier','edit_supplier','delete_supplier','purchases','purchase_action','locations','restock_plan'}
    sales={'sales_dashboard','create_sales_order','add_customer','manage_customers','edit_customer','delete_customer','return_sale'}
    reports={'filtered_reports','download_report_pdf','report_selection','low_stock_products'}

    #check login and access
    @app.before_request
    def access_boundary():
        endpoint=request.endpoint
        if endpoint is None: return None
        if endpoint not in public:
            role=session.get('role')
            valid=role=='Admin' and hmac.compare_digest(session.get('auth_stamp',''),stamp(administrator()['password']))
            if role in ('Warehouse Staff','Sales Staff'):
                user=read('SELECT * FROM users WHERE id=?',(session.get('user_id'),),True)
                valid=bool(user and user['role']==role and hmac.compare_digest(session.get('auth_stamp',''),stamp(user['password'])))
            if not valid:
                session.clear()
                if request.method!='GET' or endpoint.startswith('chatbot.'): abort(401)
                return redirect(url_for('login'))
            allowed=(endpoint in everyone or endpoint in admin and role=='Admin' or
                     endpoint in warehouse and role=='Warehouse Staff' or
                     endpoint in operations and role in ('Admin','Warehouse Staff') or
                     endpoint in sales and role in ('Admin','Sales Staff') or
                     endpoint in reports and role in ('Admin','Warehouse Staff'))
            if not allowed: abort(403)
        if request.method in ('POST','PUT','PATCH','DELETE') and app.config['CSRF_ENABLED']:
            token=request.headers.get('X-CSRF-Token') or request.form.get('_csrf','')
            if not session.get('_csrf') or not hmac.compare_digest(token,session['_csrf']): abort(400,description='Your form expired. Reload the page and try again.')
        if endpoint in ('edit_staff','delete_staff'):
            target=read('SELECT role FROM users WHERE id=?',(request.view_args['id'],),True)
            if target and target['role']=='Admin':
                flash('Use My profile to update the administrator account.','info')
                return redirect(url_for('profile'))
        # Existing account forms must preserve unique identities and hash new credentials.
        if endpoint in ('register_staff','edit_staff') and request.method=='POST':
            password=request.form.get('password','')
            if (endpoint=='register_staff' or password) and len(password)<8:
                flash('Staff passwords must contain at least 8 characters.','danger')
                return redirect(request.path)
            email=request.form.get('email','').strip()
            if email.lower()==administrator()['email'].lower():
                flash('This email belongs to the administrator.','danger')
                return redirect(request.path)
            excluded=request.view_args.get('id',0) if request.view_args else 0
            if read('SELECT id FROM users WHERE lower(email)=lower(?) AND id<>?',(email,excluded),True):
                flash('This email already belongs to another staff account.','danger')
                return redirect(request.path)
        return None

    @app.after_request
    def protect_forms(response):
        if response.mimetype=='text/html' and not response.direct_passthrough:
            token=csrf_token()
            html=response.get_data(as_text=True)
            html=re.sub(r'(<form\b[^>]*\bmethod\s*=\s*[\"\x27]?post[\"\x27]?[^>]*>)',
                        lambda m:m.group(1)+f'<input type="hidden" name="_csrf" value="{token}">',html,flags=re.I)
            html=html.replace('</head>',f'<meta name="csrf-token" content="{token}"></head>')
            response.set_data(html)
        return response


#admin, warehouse, sales staff login
    def login():
        if request.method=='POST':
            email=request.form.get('email','').strip()
            password=request.form.get('password','')
            role=None;user=None
            account=administrator()
            if email.lower()==account['email'].lower() and check_password(account['password'],password):
                role='Admin';user=account
            else:
                user=read('SELECT * FROM users WHERE lower(email)=lower(?)',(email,),True)
                if user and user['role'] in ('Warehouse Staff','Sales Staff') and check_password(user['password'],password):
                    role=user['role']
                    if not user['password'].startswith(('scrypt:','pbkdf2:')):
                        hashed=generate_password_hash(password)
                        with transaction() as c:c.execute('UPDATE users SET password=? WHERE id=?',(hashed,user['id']))
                        user=dict(user)|{'password':hashed}
            if role:
                session.clear();session['role']=role
                session['name']=user['name']
                session['auth_stamp']=stamp(user['password'])
                if user and role!='Admin': session['user_id']=user['id']
                # Compatibility fields are generated here, never used as authorization.
                session['admin_logged_in']=role=='Admin'
                session['warehouse_logged_in']=role=='Warehouse Staff'
                if role=='Warehouse Staff':
                    session['warehouse_user_id']=user['id'];session['warehouse_name']=user['name']
                return redirect(url_for({'Admin':'dashboard','Warehouse Staff':'warehouse_dashboard','Sales Staff':'sales_dashboard'}[role]))
            flash('Email or password is incorrect.','danger')
        return render_template('login.html')
    app.view_functions['login']=login
    app.view_functions['warehouse_login']=login
    app.add_url_rule('/sales-login','sales_login',login,methods=['GET','POST'])

    @app.route('/profile',methods=['GET','POST'])
    def profile():
        is_admin=session['role']=='Admin'
        user=administrator() if is_admin else read('SELECT * FROM users WHERE id=?',(session['user_id'],),True)
        if request.method=='POST':
            try:
                name=request.form.get('name','').strip();email=request.form.get('email','').strip()
                if not name or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email): raise ValueError('Name and a valid email are required.')
                if read('SELECT id FROM users WHERE lower(email)=lower(?) AND id<>?',(email,user['id'] or -1),True): raise ValueError('Email already in use.')
                if not is_admin and email.lower()==administrator()['email'].lower():
                    raise ValueError('Email already in use.')
                password=user['password']
                new=request.form.get('new_password','')
                if new or email.lower()!=user['email'].lower() or (is_admin and user['id'] is None):
                    if not check_password(password,request.form.get('current_password','')): raise ValueError('Current password is incorrect.')
                if new:
                    if len(new)<8 or new!=request.form.get('confirm_password'): raise ValueError('New password must have at least 8 characters and match confirmation.')
                    password=generate_password_hash(new)
                if is_admin and not password.startswith(('scrypt:','pbkdf2:')):
                    password=generate_password_hash(password)
                with transaction() as c:
                    if is_admin and user['id'] is None:
                        if c.execute("SELECT 1 FROM users WHERE role='Admin'").fetchone():
                            raise ValueError('Profile changed in another session. Reload and try again.')
                        c.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'Admin')",(name,email,password))
                    else:
                        c.execute('UPDATE users SET name=?,email=?,password=? WHERE id=?',(name,email,password,user['id']))
                session['name']=name;session['auth_stamp']=stamp(password)
                flash('Profile saved.','success')
                return redirect(url_for('profile'))
            except ValueError as error: flash(str(error),'danger')
        return render_template('profile.html',user=user)
    app.view_functions['warehouse_profile']=profile
    app.view_functions['warehouse_change_password']=profile

    def logout():
        session.clear();return redirect(url_for('login'))
    app.view_functions['logout']=logout;app.view_functions['warehouse_logout']=logout

    @app.errorhandler(403)
    def forbidden(error):return render_template('message.html',title='Access restricted',message='Your role cannot perform this action. Use the menu to return to your workspace.'),403
    @app.errorhandler(401)
    def unauthorized(error):return render_template('message.html',title='Sign in required',message='Please sign in before using this function.'),401
