import datetime
from ctypes import c_float_complex
from multiprocessing import connection

from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from database import create_database, get_db_connection, connect_database, DATABASE

from flask import send_file
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
)
from io import BytesIO
from chatbot import chatbot_bp
from werkzeug.security import generate_password_hash

app = Flask(__name__)
app.register_blueprint(chatbot_bp)


ADMIN_EMAIL = "admin@gmail.com"
ADMIN_PASSWORD = "admin123"


@app.route("/", methods=["GET", "POST"])  #homepage (admin login)
def login():

    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
            session["admin_logged_in"] = True
            return redirect(url_for("dashboard"))
        else:
            flash(
                "Invalid email or password.",
                "danger"
            )
            return redirect(url_for("login"))
    return render_template("login.html")

def stock_overview():
    """Read live inventory, keeping stock summary independent of table filters."""
    connection = get_db_connection()
    try:
        products = connection.execute("""
            SELECT p.*, s.supplier_name FROM products p
            LEFT JOIN suppliers s ON p.supplier_id = s.id
            ORDER BY CASE WHEN p.stock_quantity <= 0 THEN 0
                          WHEN p.stock_quantity <= p.reorder_level THEN 1 ELSE 2 END,
                     p.product_name COLLATE NOCASE
        """).fetchall()
        stats = {
            'products': len(products),
            'units': sum(p['stock_quantity'] for p in products),
            'low': sum(0 < p['stock_quantity'] <= p['reorder_level'] for p in products),
            'out': sum(p['stock_quantity'] <= 0 for p in products),
            'value': sum(p['stock_quantity'] * p['price'] for p in products),
        }
        pending = connection.execute(
            "SELECT COUNT(*) FROM stock_adjustments_request WHERE status = 'Pending'"
        ).fetchone()[0]
        categories = sorted({p['category'] for p in products if p['category']})
        query = request.args.get('q', '').strip()
        category = request.args.get('category', '')
        status = request.args.get('status', '')
        filtered = [p for p in products if
            (not query or query.casefold() in
             (str(p['id']) + ' ' + p['product_name'] + ' ' + (p['supplier_name'] or '')).casefold())
            and (not category or p['category'] == category)
            and (status not in ('low', 'out', 'healthy') or
                 (status == 'low' and 0 < p['stock_quantity'] <= p['reorder_level']) or
                 (status == 'out' and p['stock_quantity'] <= 0) or
                 (status == 'healthy' and p['stock_quantity'] > p['reorder_level']))]
        return dict(products=filtered, stats=stats, pending=pending,
                    categories=categories, query=query, selected_category=category,
                    selected_status=status)
    finally:
        connection.close()


@app.route("/dashboard")
def dashboard():
    if not session.get("role"):
        return redirect(url_for("login"))
    return render_template('dashboard.html', **stock_overview())


@app.route("/staff")
def staff_directory():
    if not session.get("role"):
        return redirect(url_for("login"))
    connection = get_db_connection()
    try:
        users = connection.execute(
            "SELECT id, name, email, role FROM users ORDER BY id DESC"
        ).fetchall()
    finally:
        connection.close()
    return render_template('staff.html', users=users)


@app.route("/register-staff", methods=["GET", "POST"])
def register_staff():

    if not session.get("role"):
        return redirect(url_for("login"))

    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm_password")
        role = request.form.get("role")


        # Check empty fields
        if not name or not email or not password or not confirm_password or not role:
            flash(
                "Please fill in all fields.",
                "danger"
            )
            return redirect(url_for("register_staff"))


        # Check password
        if password != confirm_password:
            flash(
                "Password and Confirm Password do not match.",
                "danger"
            )
            return redirect(url_for("register_staff"))

        # Check role
        if role not in ["Warehouse Staff", "Sales Staff"]:
            flash(
                "Please select a valid staff role.",
                "danger"
            )
            return redirect(url_for("register_staff"))
        connection = get_db_connection()

        try:
            connection.execute("""
                INSERT INTO users
                (name, email, password, role)
                VALUES (?, ?, ?, ?)
            """, (
                name,
                email,
                generate_password_hash(password),
                role
            ))
            connection.commit()

            flash(
                "Staff registered successfully.",
                "success"
            )
            return redirect(url_for("staff_directory"))

        except sqlite3.IntegrityError:
            connection.rollback()
            flash(
                "Email already exists.",
                "danger"
            )
            return redirect(url_for("register_staff"))

        finally:
            connection.close()

    return render_template("register_staff.html")


@app.route("/edit-staff/<int:id>", methods=["GET", "POST"])
def edit_staff(id):

    if not session.get("role"):
        return redirect(url_for("login"))

    connection = get_db_connection()

    user = connection.execute("""
        SELECT *
        FROM users
        WHERE id = ?
    """, (id,)).fetchone()


    if user is None:
        connection.close()
        flash(
            "Staff not found.",
            "danger"
        )
        return redirect(url_for("staff_directory"))


    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm_password")
        role = request.form.get("role")

        if not name or not email or not role:

            connection.close()
            flash(
                "Name, email and role are required.",
                "danger"
            )
            return redirect(url_for("edit_staff", id=id))


        # Check password only if entered
        if password:
            if password != confirm_password:
                connection.close()
                flash(
                    "Password and Confirm Password do not match.",
                    "danger"
                )
                return redirect(url_for("edit_staff", id=id))


        # Check role
        if role not in ["Warehouse Staff", "Sales Staff"]:
            connection.close()
            flash(
                "Please select a valid staff role.",
                "danger"
            )
            return redirect(url_for("edit_staff", id=id))

        try:
            # If password is changed
            if password:

                connection.execute("""
                    UPDATE users
                    SET name = ?,
                        email = ?,
                        password = ?,
                        role = ?
                    WHERE id = ?
                """, (
                    name,
                    email,
                    generate_password_hash(password),
                    role,
                    id
                ))

            # If password is not changed
            else:

                connection.execute("""
                    UPDATE users
                    SET name = ?,
                        email = ?,
                        role = ?
                    WHERE id = ?
                """, (
                    name,
                    email,
                    role,
                    id
                ))
            connection.commit()
            flash(
                "Staff updated successfully.",
                "success"
            )
            return redirect(url_for("staff_directory"))

        except sqlite3.IntegrityError:
            connection.rollback()
            flash(
                "Email already exists.",
                "danger"
            )
            return redirect(url_for("edit_staff", id=id))

        finally:
            connection.close()
    connection.close()

    return render_template(
        "edit_staff.html",
        user=user
    )

@app.route("/delete-staff/<int:id>", methods=["GET", "POST"])
def delete_staff(id):

    if not session.get("role"):
        return redirect(url_for("login"))
    connection = get_db_connection()

    connection.execute("""
        DELETE FROM users
        WHERE id = ?
    """, (id,))

    connection.commit()
    connection.close()

    flash(
        "Staff deleted successfully.",
        "success"
    )
    return redirect(url_for("staff_directory"))


@app.route("/logout")
def logout():

    session.clear()
    return redirect(url_for("login"))


@app.route("/warehouse-login", methods=["GET", "POST"])
def warehouse_login():

    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        connection = get_db_connection()
        user = connection.execute("""
        SELECT *
        FROM users
        WHERE email = ?
        AND password = ?
        AND role = 'Warehouse Staff'
        """, (email, password)).fetchone()

        connection.close()

        if user:
            session["warehouse_logged_in"] = True
            session["warehouse_user_id"] = user["id"]
            session["warehouse_name"] = user["name"]
            session["warehouse_email"] = user["email"]
            session["warehouse_role"] = user["role"]

            return redirect(url_for("warehouse_dashboard"))

        else:
            flash("Invalid email or password.", "danger")
            return redirect(url_for("warehouse_login"))
    return render_template("warehouse_login.html")

#========================
#admin manage products
#==========================
@app.route("/manage-products")
def manage_products():
    if not session.get("role"):
        return redirect(url_for("login"))
    connection = get_db_connection()

    products = connection.execute("""
          SELECT 
             products.id,
             products.product_name,
             products.category,
             suppliers.supplier_name,
             products.price,
             products.stock_quantity,
             products.reorder_level,
             products.description
          
          FROM products
          
          INNER JOIN suppliers
               ON products.supplier_id = suppliers.id
               
          ORDER BY products.id DESC
    """).fetchall()

    connection.close()
    return render_template(
        "manage_products.html",
        products=products
    )


#===========================
#admin - add product
#============================
@app.route("/add-product", methods=["GET", "POST"])
def add_product():
     if not session.get("role"):
        return redirect(url_for("login"))

     connection = get_db_connection()

     #Get suppliers for dropdown
     suppliers = connection.execute("""
          SELECT id,supplier_name
          FROM suppliers
          ORDER BY supplier_name ASC
     """).fetchall()
     if request.method == "POST":

         product_name = request.form.get("product_name")
         category = request.form.get("category")
         supplier_id = request.form.get("supplier_id")
         price = request.form.get("price")
         stock_quantity = request.form.get("stock_quantity")
         reorder_level = request.form.get("reorder_level")
         description = request.form.get("description")

         if not product_name or not category or not supplier_id or not price:
             connection.close()

             flash("Please fill all required fields.", "danger")

             return render_template("add_product.html", suppliers=suppliers)

         connection.execute("""         
         INSERT INTO products(
         product_name,
         category,
         supplier_id,
         price,
         stock_quantity,
         reorder_level,
         description
         )
         VALUES (?,?,?,?,?,?,?)
     """,(
         product_name,
         category,
         supplier_id,
         price,
         stock_quantity or 0,
         reorder_level or 10,
         description
     ))
         connection.commit()
         connection.close()

         flash("Product added successfully.", "success")
         return redirect(url_for("manage_products"))

     connection.close()

     return render_template("add_product.html",suppliers=suppliers)
#===============================
#admin-edit products
#===================================

@app.route("/edit-product/<int:id>", methods=["GET", "POST"])
def edit_product(id):
    if not session.get("role"):
        return redirect(url_for("login"))

    connection = get_db_connection()

    product = connection.execute("""
         SELECT *
         FROM products
         WHERE id = ?
    """, (id,)).fetchone()

    if product is None:
        connection.close()
        flash("Product not found.", "danger")
        return redirect(url_for("manage_products"))
    suppliers = connection.execute("""
          SELECT id,supplier_name
          FROM suppliers
          ORDER BY supplier_name ASC
    """).fetchall()


    if request.method == "POST":

        product_name = request.form.get("product_name")
        category = request.form.get("category")
        supplier_id = request.form.get("supplier_id")
        price = request.form.get("price")
        stock_quantity = request.form.get("stock_quantity")
        reorder_level = request.form.get("reorder_level")
        description = request.form.get("description")
        if not product_name or not category or not supplier_id or not price:
            connection.close()
            flash("Please fill all required fields.", "danger")
            return render_template("edit_product.html", product=product, suppliers=suppliers)

        connection.execute("""
            UPDATE products
            
            SET product_name = ?,
                category = ?,
                supplier_id = ?,
                price = ?,
                stock_quantity = ?,
                reorder_level = ?,
                description = ?
            
            WHERE id = ?
        """, (product_name, category, supplier_id, price, stock_quantity, reorder_level, description,id))
        connection.commit()
        connection.close()

        flash("Product updated successfully.", "success")
        return redirect(url_for("manage_products"))
    connection.close()
    return render_template("edit_product.html",product=product,suppliers=suppliers)


#=========================
#admin delete product
#==========================
@app.route("/delete-product/<int:id>", methods=["POST"])
def delete_product(id):
    if not session.get("role"):
        return redirect(url_for("login"))

    connection = get_db_connection()
    connection.execute("""
        DELETE FROM products  
        WHERE id = ?
    """,(id,))
    connection.commit()
    connection.close()
    flash("Product deleted successfully.", "success")
    return redirect(url_for("manage_products"))










#warehouse staff dashboard
@app.route("/warehouse-dashboard")
def warehouse_dashboard():
    if not session.get("role"):
        return redirect(url_for("warehouse_login"))
    return render_template('dashboard.html', warehouse_view=True, **stock_overview())

#--------------------------
#Supplier management
#------------------------

@app.route("/manage-suppliers")
def manage_suppliers():
    if not session.get("role"):
        return redirect(url_for("warehouse_login"))
    connection = get_db_connection()
    suppliers = connection.execute("SELECT * FROM suppliers ORDER BY id DESC").fetchall()
    connection.close()

    return render_template("manage_suppliers.html", suppliers=suppliers)

@app.route("/suppliers-add", methods=["GET", "POST"])
def add_supplier():
    if not session.get("role"):
        return redirect(url_for("warehouse_login"))

    if request.method == "POST":
        supplier_name = request.form.get("supplier_name")
        contact_person = request.form.get("contact_person")
        phone = request.form.get("phone")
        email = request.form.get("email")
        address = request.form.get("address")

        #Basic validation
        if not supplier_name or not contact_person or not phone or not email or not address:
            flash("Please fill in all fields.", "danger")
            return redirect(url_for("add_supplier"))
        connection = get_db_connection()
        connection.execute("""
        INSERT INTO suppliers
        (supplier_name, contact_person, phone, email, address)
        VALUES (?, ?, ?, ?, ?)
        """, (supplier_name, contact_person, phone, email, address))
        connection.commit()
        connection.close()
        flash("Supplier added successfully.", "success")
        return redirect(url_for("manage_suppliers"))
    return render_template("add_supplier.html")
#===========================
#Edit supplier
#================================
@app.route("/suppliers/edit/<int:supplier_id>", methods=["GET", "POST"])
def edit_supplier(supplier_id):
    if not session.get("role"):
        return redirect(url_for("warehouse_login"))
    connection = get_db_connection()

    supplier = connection.execute("SELECT * FROM suppliers WHERE id = ?", (supplier_id,)).fetchone()
    if supplier is None:
        connection.close()
        flash("Supplier not found.", "danger")
        return redirect(url_for("manage_supplier"))

    if request.method == "POST":

        supplier_name = request.form.get("supplier_name")
        contact_person = request.form.get("contact_person")
        phone = request.form.get("phone")
        email = request.form.get("email")
        address = request.form.get("address")

        if not supplier_name or not contact_person or not phone or not email or not address:
            connection.close()
            flash("Please fill in all fields.", "danger")

            return redirect(url_for("edit_supplier", supplier_id=supplier_id))
        connection.execute("""
            UPDATE suppliers
            SET supplier_name = ?,
                contact_person = ?,
                phone = ?,
                email = ?,
                address = ?
            WHERE id = ?
        """, (supplier_name, contact_person, phone, email, address,supplier_id))
        connection.commit()
        connection.close()
        flash("Supplier edited successfully.", "success")
        return redirect(url_for("manage_suppliers"))
    connection.close()
    return render_template("edit_supplier.html", supplier=supplier)


#=========================================
#delete supplier
#==========================================
@app.route("/supplier/delete/<int:supplier_id>", methods=["POST"])
def delete_supplier(supplier_id):
    if not session.get("role"):
        return redirect(url_for("warehouse_login"))
    connection = get_db_connection()
    connection.execute("DELETE FROM suppliers WHERE id = ?", (supplier_id,))
    connection.commit()
    connection.close()
    flash("Supplier deleted successfully.", "success")
    return redirect(url_for("manage_suppliers"))

#================================
#warehouse staff logout
#================================

@app.route("/warehouse-logout")
def warehouse_logout():
    #clear the warehouse staff session
    session.clear()

    #redirect to warehouse login page
    return redirect(url_for("warehouse_login"))




#warehouse staff -manage profile
@app.route("/warehouse-profile", methods=["GET", "POST"])
def warehouse_profile():
    if not session.get("role"):
        return redirect(url_for("warehouse_login"))
    connection = get_db_connection()

    user = connection.execute("""
    SELECT *
    FROM users
    WHERE id = ?
    AND role = 'Warehouse Staff'
    """, (session["warehouse_user_id"],)).fetchone()

    if user is None:
        connection.close()
        session.clear()

        flash("User account not found.", "danger")
        return redirect(url_for("warehouse_login"))

    #update profile
    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        #check fields
        if not name or not email:
            connection.close()
            flash("Name and Email are required.", "danger")
            return redirect(url_for("warehouse_profile"))
        try:
            connection.execute("""
               UPDATE users
               SET name = ?,
                   email = ?
               WHERE id = ?
               AND role = 'Warehouse Staff'
            """,(name,email,session["warehouse_user_id"],))
            connection.commit()

            #Update session

            session["warehouse_name"] = name
            session["warehouse_email"] = email
            flash("Profile updated successfully.", "success")
            return redirect(url_for("warehouse_profile"))
        except sqlite3.IntegrityError:
            connection.rollback()
            flash("Email already exists.", "danger")

            return redirect(url_for("warehouse_profile"))
        finally:
            connection.close()
    else:
        connection.close()

    return render_template(
        "warehouse_profile.html",
        user=user)


#warehouse staff - change password
@app.route("/warehouse-change-password", methods=["POST"])
def warehouse_change_password():
    if not session.get("role"):
        return redirect(url_for("warehouse_login"))

    current_password = request.form.get("current_password")
    new_password = request.form.get("new_password")
    confirm_password = request.form.get("confirm_password")
    #Check fields
    if not current_password or not new_password or not confirm_password:
        flash("Please fill all password fields.", "danger")

        return redirect(url_for("warehouse_profile"))

    #Check new password
    if new_password != confirm_password:
        flash("New passwords and confirm password do not match.", "danger")

        return redirect(url_for("warehouse_profile"))
    #password length
    if len(new_password) < 6:
        flash("New password must be at least 6 characters.", "danger")

        return redirect(url_for("warehouse_profile"))

    connection = get_db_connection()

    #check current password
    user = connection.execute("""
         SELECT *
         FROM users
         WHERE id = ?
         AND role = 'Warehouse Staff'
    """, (session["warehouse_user_id"],)).fetchone()

    if user is None:
        connection.close()
        session.clear()

        return redirect(url_for("warehouse_login"))

    if user["password"] != current_password:
        connection.close()
        flash("Current password is incorrect.", "danger")
        return redirect(url_for("warehouse_profile"))
    #Update password
    connection.execute("""
        UPDATE users
        SET password = ?
        WHERE id = ?
    """, (new_password, session["warehouse_user_id"]))
    connection.commit()
    connection.close()

    flash("Password changed successfully.", "success")
    return redirect(url_for("warehouse_profile"))

@app.route("/stock-adjustment-request", methods=["GET","POST"])
def stock_adjustment_request():

    #Only Warehouse Staff can access
    if not session.get("role"):
        return redirect(url_for("warehouse_login"))

    connection = get_db_connection()

    #Get all products
    products = connection.execute("""
        SELECT id, product_name, stock_quantity
        FROM products
        ORDER BY product_name ASC
    """).fetchall()

    #When form is submitted
    if request.method == "POST":

        product_id = request.form.get("product_id")
        actual_quantity = request.form.get("actual_quantity")
        reason = request.form.get("reason")
        remarks = request.form.get("remarks")

        #Check required fields
        if not product_id or not actual_quantity or not reason:
            connection.close()
            flash("Please fill in all required fields.", "danger")
            return redirect(url_for("stock_adjustment_request"))

        #convert actual quantity to integer
        try:
            actual_quantity = int(actual_quantity)
        except ValueError:
            connection.close()
            flash("Actual quantity must be a valid number.", "danger")
            return redirect(url_for("stock_adjustment_request"))

        #quantity cannot be negative
        if actual_quantity < 0:
            connection.close()
            flash("Actual quantity cannot be negative.", "danger")
            return redirect(url_for("stock_adjustment_request"))

        #Get selected product
        product = connection.execute("""
            SELECT id, product_name, stock_quantity
            FROM products
            WHERE id = ?
        """, (product_id,)).fetchone()

        if product is None:
            connection.close()
            flash("Product not found.", "danger")
            return redirect(url_for("stock_adjustment_request"))

        #Current quantity from database
        current_quantity = product["stock_quantity"]

        #calculate adjustment
        adjustment_quantity = actual_quantity - current_quantity

        #Insert request
        connection.execute("""
            INSERT INTO stock_adjustments_request
            (
                product_id,
                warehouse_user_id,
                current_quantity,
                actual_quantity,
                adjustment_quantity,
                reason,
                remarks,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,(
            product_id,
            session["warehouse_user_id"],
            current_quantity,
            actual_quantity,
            adjustment_quantity,
            reason,
            remarks,
            "Pending"
        ))
        operations.notify(connection, 'Stock count awaiting review', 'A warehouse count needs approval.', 'Admin')
        connection.commit()
        connection.close()

        flash(
            "Stock adjustment requested successfully.",
            "success"
        )

        return redirect(url_for("stock_adjustment_request"))

    connection.close()

    return render_template(
        "stock_adjustment_request.html",
        products = products,
    )

@app.route("/admin/stock-adjustment-requests")
def admin_stock_adjustment_requests():

    #Only admin can access
    if not session.get("role"):
        return redirect(url_for("login"))

    connection = get_db_connection()

    requests = connection.execute("""
        SELECT
            sar.id,
            sar.current_quantity,
            sar.actual_quantity,
            sar.adjustment_quantity,
            sar.reason,
            sar.remarks,
            sar.status,
            sar.request_date,
            
            p.product_name,
            
            u.name AS warehouse_staff
            
        FROM stock_adjustments_request sar
        
        JOIN products p
            ON sar.product_id = p.id
            
        JOIN users u
            ON sar.warehouse_user_id = u.id
            
        ORDER BY sar.request_date DESC
    """).fetchall()

    connection.close()

    return render_template(
        "admin_stock_adjustment_requests.html",
        requests = requests
    )

@app.route("/admin/stock-adjustment/approve/<int:request_id>", methods=["POST"])
def approve_stock_adjustment(request_id):

    #Only admin can approve
    if not session.get("role"):
        return redirect(url_for("login"))

    connection = get_db_connection()

    try:

        #get the adjustment request
        adjustment_request = connection.execute("""
            SELECT *
            FROM stock_adjustments_request
            WHERE id = ?
        """, (request_id,)).fetchone()

        #check request exists
        if adjustment_request is None:

            connection.close()

            flash(
                "Stock adjustment request not found.",
                "danger"
            )

            return redirect(
                url_for("admin_stock_adjustment_requests")
            )

        #check request is still pending
        if adjustment_request["status"] != "Pending":

            connection.close()

            flash(
                "This request has already been processed.",
                "warning"
            )

            return redirect(
                url_for("admin_stock_adjustment_requests")
            )

        #update product stock
        connection.execute("""
            UPDATE products
            SET stock_quantity = ?
            WHERE id = ?
        """,(
            adjustment_request["actual_quantity"],
            adjustment_request["product_id"],
        ))

        #Update request status
        connection.execute("""
            UPDATE stock_adjustments_request
            SET status = 'Approved'
            WHERE id = ?
        """, (request_id,))

        #save both changes
        connection.commit()

        flash(
            "Stock adjustment approved and stock quantity updated.",
            "success"
        )

    except sqlite3.Error as error:

        connection.rollback()

        flash(
            "Error approving stock adjustment: " + str(error),
            "danger"
        )

    finally:

        connection.close()

    return redirect(
        url_for("admin_stock_adjustment_requests")
    )

@app.route("/admin/stock-adjustment/reject/<int:request_id>", methods=["POST"])
def reject_stock_adjustment(request_id):

    #only admin can reject
    if not session.get("role"):
        return redirect(url_for("login"))

    connection = get_db_connection()

    try:

        #get the request
        adjustment_request = connection.execute("""
            SELECT *
            FROM stock_adjustments_request
            WHERE id = ?
        """, (request_id,)).fetchone()

        #Check request exists
        if adjustment_request is None:

            connection.close()

            flash(
                "Stock adjustment request not found.",
                "danger"
            )

            return redirect(
                url_for("admin_stock_adjustment_requests")
            )

        #check request is still pending
        if adjustment_request["status"] != "Pending":

            connection.close()
            flash(
            "This request has already been processed.",
            "warning"
            )

            return redirect(
                url_for("admin_stock_adjustment_requests")
            )

        #change status to rejected
        connection.execute("""
            UPDATE stock_adjustments_request
            SET status = 'Rejected'
            WHERE id = ?
        """, (request_id,))

        operations.notify(connection, 'Stock adjustment rejected', f'Request #{request_id} rejected. Please review your count.', 'Warehouse Staff')
        connection.commit()

        flash(
            "Stock adjustment request rejected.",
            "success"
        )
    except sqlite3.Error as error:

        connection.rollback()

        flash(
            "Error rejecting stock adjustment: " + str(error),
            "danger"
        )

    finally:
        connection.close()

    return redirect(
        url_for("admin_stock_adjustment_requests")
    )

@app.route('/admin/inventory', methods=['GET','POST'])
def manage_inventory():

    connection = connect_database(DATABASE)
    connection.row_factory = sqlite3.Row

    if request.method == "POST":

        product_id = request.form["product_id"]
        adjustment_type = request.form["adjustment_type"]
        adjustment_quantity = int(request.form["adjustment_quantity"])

        if adjustment_quantity <= 0:
            flash("Quantity must be greater than 0.", "danger")
            return redirect(url_for("manage_inventory"))

        product = connection.execute(
            "SELECT * FROM products WHERE id = ?",
            (product_id,)
        ).fetchone()

        if product is None:
            flash("Product not found.", "danger")
            connection.close()
            return redirect(url_for("manage_inventory"))

        current_quantity = product["stock_quantity"]

        if adjustment_type == 'add':

            new_quantity = current_quantity + adjustment_quantity

        elif adjustment_type == 'reduce':

            new_quantity = current_quantity - adjustment_quantity

            if new_quantity < 0:
                flash(
                    f"Cannot reduce stock. Current quantity is {current_quantity}.",
                    "danger"
                )
                connection.close()
                return redirect(url_for("manage_inventory"))

        else:
            flash(
                "Invalid stock adjustment.",
                "danger"
            )
            connection.close()
            return redirect(url_for("manage_inventory"))

        connection.execute(
            "UPDATE products SET stock_quantity = ? WHERE id = ?",
            (new_quantity, product_id)
        )

        connection.commit()
        connection.close()

        flash(
            f"Stock updated successfully. New quantity: {new_quantity}.",
            "success"
        )

        return redirect(url_for("manage_inventory"))

    products = connection.execute(
        "SELECT * FROM products ORDER BY product_name"
    ).fetchall()

    connection.close()

    return render_template("inventory.html", products = products)

@app.route('/admin/low-stock')
def low_stock_products():

    connection = get_db_connection()

    products = connection.execute("""
        SELECT
            products.id,
            products.product_name,
            products.category,
            suppliers.supplier_name,
            products.price,
            products.stock_quantity,
            products.reorder_level
        FROM products
        LEFT JOIN suppliers
            ON products.supplier_id = suppliers.id
        WHERE products.stock_quantity <= products.reorder_level
        ORDER BY products.stock_quantity ASC
    """).fetchall()

    connection.close()

    return render_template(
        "low_stock_products.html",
        products = products
    )

@app.route('/add_customer', methods=['GET','POST'])
def add_customer():

    if request.method == "POST":
        customer_name = request.form['customer_name']
        phone = request.form['phone']
        email = request.form['email']
        address = request.form['address']

        connection = connect_database(DATABASE)
        connection.execute("""
            INSERT INTO customers
            (customer_name, phone, email, address)
            VALUES (?, ?, ?, ?)
        """, (
            customer_name,
            phone,
            email,
            address
        ))
        connection.commit()
        connection.close()

        flash("Customer added successfully.", "success")
        return redirect(url_for('manage_customers'))
    return render_template('add_customer.html')

@app.route('/manage_customers')
def manage_customers():

    search = request.args.get("search", '').strip()
    connection = connect_database(DATABASE)
    connection.row_factory = sqlite3.Row

    if search:
        customers = connection.execute("""
            SELECT *
            FROM customers
            WHERE customer_name LIKE ?
                OR phone LIKE ?
                OR email LIKE ?
            ORDER BY id DESC
        """,(
            '%'+search+'%',
            '%'+search+'%',
            '%'+search+'%'
        )).fetchall()

    else:
        customers = connection.execute("""
            SELECT *
            FROM customers
            ORDER BY id DESC
        """).fetchall()

    connection.close()

    return render_template(
        "manage_customers.html",
        customers = customers
    )

@app.route('/edit_customer/<int:id>', methods=['GET','POST'])
def edit_customer(id):

    connection = connect_database(DATABASE)
    connection.row_factory = sqlite3.Row
    customer = connection.execute("""
        SELECT *
        FROM customers
        WHERE id = ?
    """,(id,)).fetchone()

    if customer is None:
        connection.close()

        flash("Customer not found.", "danger")
        return redirect(url_for("manage_customers"))

    if request.method == 'POST':

        customer_name = request.form['customer_name']
        phone = request.form['phone']
        email = request.form['email']
        address = request.form['address']

        connection.execute("""
            UPDATE customers
            SET customer_name = ?,
                phone = ?,
                email = ?,
                address = ?
            WHERE id = ?
        """,(
            customer_name,
            phone,
            email,
            address,
            id
        ))
        connection.commit()
        connection.close()

        flash("Customer updated successfully.", "success")
        return redirect(url_for("manage_customers"))
    connection.close()

    return render_template(
        "edit_customer.html",
        customer = customer
    )

@app.route('/delete_customer/<int:id>', methods=['GET','POST'])
def delete_customer(id):

    connection = connect_database(DATABASE)

    customer = connection.execute("""
        SELECT id
        FROM customers
        WHERE id = ?
    """,(id,)).fetchone()

    if customer is None:
        connection.close()

        flash("Customer not found.", "danger")

        return redirect(url_for("manage_customers"))

    connection.execute("""
        DELETE FROM customers
        WHERE id = ?
    """,(id,))

    connection.commit()
    connection.close()

    flash("Customer deleted successfully.", "success")

    return redirect(url_for("manage_customers"))

@app.route ("/admin/sales-orders")
def sales_orders():
    if not session.get("role"):
        return redirect(url_for("login"))

    orders = get_sales_orders()

    return render_template(
        "sales_orders.html",
        orders = orders
    )

@app.route("/admin/sales-order/<int:order_id>")
def view_sales_order(order_id):
    connection = connect_database(DATABASE)
    connection.row_factory = sqlite3.Row

    order = connection.execute("""
        SELECT
            so.id,
            so.order_date,
            so.total_amount,
            so.payment,
            so.status,
            c.customer_name,
            c.phone,
            c.email,
            c.address
        FROM sales_orders so
        LEFT JOIN customers c 
            ON so.customer_id = c.id
        WHERE so.id = ?
    """,(order_id,)).fetchone()

    if order is None:
        connection.close()
        flash("Sales order not found.", "danger")
        return redirect(url_for("sales_orders"))

    items = connection.execute("""
        SELECT
            soi.id,
            p.product_name,
            soi.quantity,
            soi.unit_price,
            soi.subtotal
        FROM sales_order_items soi
        LEFT JOIN products p
            ON soi.product_id = p.id
        WHERE soi.order_id = ?
        ORDER BY soi.id
    """,(order_id,)).fetchall()

    connection.close()

    return render_template(
        'view_sales_order.html',
        order = order,
        items = items
    )

def get_sales_orders():
    connection = get_db_connection()

    try:
        cursor = connection.cursor()

        cursor.execute("""
            SELECT
                so.id,
                c.customer_name,
                c.phone,
                so.order_date,
                so.total_amount,
                so.status,
                p.payment_method,
                p.payment_status
            FROM sales_orders so
            
            INNER JOIN customers c 
                ON so.customer_id = c.id
                
            LEFT JOIN payments p 
                ON so.id = p.order_id
                
            ORDER BY so.order_date DESC
        """)

        return cursor.fetchall()
    finally:
        connection.close()

@app.route('/admin/create-sales-order', methods=['GET','POST'])
def create_sales_order():

    if not session.get("role"):
        return redirect(url_for("login"))

    connection = None

    try:
        connection = connect_database(DATABASE)
        connection.row_factory = sqlite3.Row

        customers = connection.execute("""
            SELECT
                id,
                customer_name,
                phone,
                email,
                address
            FROM customers
            ORDER BY customer_name
        """).fetchall()

        products = connection.execute("""
            SELECT
                id,
                product_name,
                category,
                price,
                stock_quantity,
                reorder_level,
                description
            FROM products
            WHERE stock_quantity > 0
            ORDER BY product_name
        """).fetchall()

        if request.method == "GET":
            return render_template(
                "create_sales_order.html",
                customers = customers,
                products = products
            )

        customer_id = request.form.get("customer_id")

        if not customer_id:

            flash(
                "Please select a customer.",
                "danger"
            )

            return render_template(
                "create_sales_order.html",
                customers = customers,
                products = products
            )

        payment = request.form.get("payment")

        if not payment:

            flash(
                "Please select a payment method.",
                "danger"
            )

            return render_template(
                "create_sales_order.html",
                customers = customers,
                products = products
            )

        customer = connection.execute("""
            SELECT
                id,
                customer_name
            FROM customers
            WHERE id = ?
        """,(customer_id,)).fetchone()

        if customer is None:

            flash(
                "Customer not found.",
                "danger"
            )

            return render_template(
                "create_sales_order.html",
                customers = customers,
                products = products
            )

        product_ids = request.form.getlist("product_id[]")

        quantities = request.form.getlist("quantity[]")

        if not product_ids:

            flash(
                "Please add at least one product.",
                "danger"
            )

            return render_template(
                "create_sales_order.html",
                customers = customers,
                products = products
            )

        total_amount = 0

        order_items = []

        for product_id, quantity in zip(
            product_ids,
            quantities
        ):

            if not product_id or not quantity:
                continue

            try:
                quantity = int(quantity)
            except ValueError:

                flash(
                    "Quantity must be a valid number.",
                    "danger"
                )
                return render_template(
                    "create_sales_order.html",
                    customers = customers,
                    products = products
                )

            if quantity <= 0:

                flash(
                    "Quantity must be greater than zero.",
                    "danger"
                )

                return render_template(
                    "create_sales_order.html",
                    customers = customers,
                    products = products
                )

            product = connection.execute("""
                SELECT
                    id,
                    product_name,
                    price,
                    stock_quantity
                FROM products
                WHERE id = ?
            """,(product_id,)).fetchone()

            if product is None:

                flash(
                    "Product not found.",
                    "danger"
                )

                return render_template(
                    "create_sales_order.html",
                    customers = customers,
                    products = products
                )

            available_stock = product[
                "stock_quantity"
            ]

            if quantity > available_stock:

                flash(
                    f"Not enough stock for "
                    f"{product['product_name']}. "
                    f"Available stock: "
                    f"{available_stock}.",
                    "danger"
                )

                return render_template(
                    "create_sales_order.html",
                    customers = customers,
                    products = products
                )

            unit_price = float(
                product["price"]
            )

            sub_total = (
                unit_price * quantity
            )


            total_amount += sub_total

            order_items.append({

                "product_id":
                    int(product_id),

                "quantity":
                    quantity,

                "unit_price":
                    unit_price,

                "subtotal":
                    sub_total

            })

        if not order_items:

            flash(
                "Please enter a quantity for at least one product.",
                "danger"
            )

            return render_template(
                "create_sales_order.html",
                customers = customers,
                products = products
            )

        order_date = datetime.datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        cursor = connection.execute("""
            INSERT INTO sales_orders
            (
                customer_id,
                order_date,
                total_amount,
                payment,
                status
            )
            VALUES (?, ?, ?, ?, ?)
        """,(
            customer_id,

            order_date,

            total_amount,

            payment,

            "Completed"
        ))

        order_id = cursor.lastrowid

        for item in order_items:

            connection.execute("""
                INSERT INTO sales_order_items
                (
                    order_id,
                    product_id,
                    quantity,
                    unit_price,
                    subtotal
                )
                VALUES (?, ?, ?, ?, ?)
            """,(

                order_id,

                item["product_id"],

                item["quantity"],

                item["unit_price"],

                item["subtotal"],

            ))

            connection.execute("""
                UPDATE products
                SET stock_quantity =
                    stock_quantity - ?
                WHERE id = ?
            """,(

                item["quantity"],

                item["product_id"]

            ))

            connection.execute("""
                INSERT INTO payments
                (
                    order_id,
                    payment_method,
                    amount,
                    payment_status
                )
                VALUES (?, ?, ?, ?)
            """,(

                order_id,
                payment,
                total_amount,
                "Paid"
            ))

        connection.commit()

        flash(
            "Sales order created successfully.",
            "success"
        )
        return redirect(
            url_for(
                "view_sales_order",
                order_id=order_id
            )
        )

    except sqlite3.Error as error:

        if connection:
            connection.rollback()

        print(
            "DATABASE ERROR:",
            error
        )
        flash(
            "A database error occurred. Please try again.",
            "danger"
        )
        return redirect(url_for("create_sales_order"))

    except Exception as error:

        if connection:
            connection.rollback()

        print(
            "CREATE SALES ORDER ERROR:",
            error
        )

        flash(
            "An unexpected error occurred. Please try again.",
            "danger"
        )

        return redirect(url_for("create_sales_order"))

    finally:

        if connection:
            connection.close()

@app.route('/admin/sales-order/<int:order_id>/pdf')
def sales_order_pdf(order_id):

    if not session.get("role"):
        return redirect(url_for("login"))
    connection = get_db_connection()

    try:
        order = connection.execute("""
            SELECT
                so.id,
                so.order_date,
                so.total_amount,
                so.payment,
                so.status,
                
                c.customer_name,
                c.phone,
                c.email,
                c.address
                
                FROM sales_orders so
                LEFT JOIN customers c
                    ON so.customer_id = c.id
                
                WHERE so.id = ?
                
            """,(order_id,)).fetchone()


        if order is None:

            flash(
                "Sales order not found.",
                "danger"
            )

            return redirect(
                url_for("sales_orders")
            )

        items = connection.execute("""
            SELECT
                soi.id,
                p.product_name,
                soi.quantity,
                soi.unit_price,
                soi.subtotal
            FROM sales_order_items soi
            
            LEFT JOIN products p 
                ON soi.product_id = p.id
                
            WHERE soi.order_id = ?
            
            ORDER BY soi.id
            
        """,(order_id,)).fetchall()

        payment = connection.execute("""
            SELECT
                
                payment_method,
                amount,
                payment_date,
                payment_status
            
            FROM payments
            
            WHERE order_id = ?
            
            ORDER BY id DESC
            
            LIMIT 1
            
        """,(order_id,)).fetchone()

        return render_template(
            "sales_order_pdf.html",
            order = order,
            items = items,
            payment = payment
        )

    finally:

        connection.close()

@app.route("/filtered-reports")
def filtered_reports():
    report_type = request.args.get("type", "available")

    connection = get_db_connection()

    try:
        if report_type == "available":
            report_title = "Available Stock Report"


            records = connection.execute("""
                SELECT p.id, p.product_name, p.category,
                       s.supplier_name, p.price,
                       p.stock_quantity, p.reorder_level
                FROM products p
                LEFT JOIN suppliers s
                    ON p.supplier_id = CAST(s.id AS TEXT)
                WHERE p.stock_quantity > 0
                ORDER BY p.product_name
            """).fetchall()

        elif report_type == "low":
            report_title = "Low-Stock Items Report"

            records = connection.execute("""
                SELECT p.id, p.product_name, p.category,
                       s.supplier_name, p.price,
                       p.stock_quantity, p.reorder_level
                FROM products p
                LEFT JOIN suppliers s
                    ON p.supplier_id = CAST(s.id AS TEXT)
                WHERE p.stock_quantity > 0
                    AND p.stock_quantity <= p.reorder_level
                ORDER BY p.stock_quantity
            """).fetchall()

        elif report_type == "out":
            report_title = "Out-of-Stock Items Report"

            records = connection.execute("""
                SELECT p.id, p.product_name, p.category,
                       s.supplier_name, p.price,
                       p.stock_quantity, p.reorder_level
                FROM products p
                LEFT JOIN suppliers s
                    ON p.supplier_id = CAST(s.id AS TEXT)
                WHERE p.stock_quantity = 0
                ORDER BY p.product_name
            """).fetchall()

        elif report_type == "suppliers":
            report_title = "Supplier Records Report"

            records = connection.execute("""
                SELECT id, supplier_name, contact_person,
                       phone, email, address
                FROM suppliers
                ORDER BY supplier_name
            """).fetchall()

        else:
            return "Invalid report type", 400

        return render_template(
            "filtered_reports.html",
            report_type = report_type,
            report_title = report_title,
            records = records
        )

    finally:
        connection.close()

@app.route("/download-report-pdf")
def download_report_pdf():
    report_type = request.args.get("type", "available")

    connection = get_db_connection()

    try:
        if report_type == "available":
            title = "Available Stock Reports"
            headers = [
                "ID", "Product", "Category", "Supplier",
                "Price (RM)", "Stock", "Reorder Level"
            ]

            records = connection.execute("""
                SELECT p.id, p.product_name, p.category,
                       COALESCE(s.supplier_name, 'N/A'),
                       p.price, p.stock_quantity, p.reorder_level
                FROM products p
                LEFT JOIN suppliers s
                    ON p.supplier_id = CAST(s.id AS TEXT)
                WHERE p.stock_quantity > 0
                ORDER BY p.product_name
            """).fetchall()

            rows = [
                [r[0], r[1], r[2], r[3],
                 f"{r[4]:.2f}", r[5], r[6]]
                for r in records
            ]

        elif report_type == "low":
            title = "Low-Stock Items Report"
            headers = [
                "ID", "Product", "Category", "Supplier",
                "Price (RM)", "Stock", "Reorder Level"
            ]

            records = connection.execute("""
                SELECT p.id, p.product_name, p.category,
                       COALESCE(s.supplier_name, 'N/A'),
                       p.price, p.stock_quantity, p.reorder_level
                FROM products p
                LEFT JOIN suppliers s
                    ON p.supplier_id = CAST(s.id AS TEXT)
                WHERE p.stock_quantity > 0
                  AND p.stock_quantity <= p.reorder_level
                ORDER BY p.stock_quantity
            """).fetchall()

            rows = [
                [r[0], r[1], r[2], r[3],
                 f"{r[4]:.2f}", r[5], r[6]]
                for r in records
            ]

        elif report_type == "out":
            title = "Out-of-Stock Items Report"
            headers = [
                "ID", "Product", "Category", "Supplier",
                "Price (RM)", "Stock", "Reorder Level"
            ]

            records = connection.execute("""
                SELECT p.id, p.product_name, p.category,
                       COALESCE(s.supplier_name, 'N/A'),
                       p.price, p.stock_quantity, p.reorder_level
                FROM products p
                LEFT JOIN suppliers s
                    ON p.supplier_id = CAST(s.id AS TEXT)
                WHERE p.stock_quantity = 0
                ORDER BY p.product_name
            """).fetchall()

            rows = [
                [r[0], r[1], r[3],
                 f"{r[4]:.2f}", r[5], r[6]]
                for r in records
            ]

        elif report_type == "suppliers":
            title = "Supplier Records Report"
            headers = [
                "ID", "Supplier Name", "Contact Person",
                "Phone", "Email", "Address"
            ]

            records = connection.execute("""
                SELECT id, supplier_name, contact_person,
                       phone, email, address
                FROM suppliers
                ORDER BY supplier_name
            """).fetchall()

            rows = [
                [r[0], r[1], r[2], r[3], r[4], r[5]]
                for r in records
            ]

        else:
            return "Invalid report type", 400

    finally:
        connection.close()


    # Create PDF in memory
    pdf_buffer = BytesIO()

    page_size = landscape(A4)

    document = SimpleDocTemplate(
        pdf_buffer,
        pagesize=page_size,
        rightMargin =12 * mm,
        leftMargin =12 * mm,
        topMargin = 15 * mm,
        bottomMargin = 15 * mm
    )

    styles = getSampleStyleSheet()
    elements = []

    elements.append(Paragraph(
        "Inventory Management System",
        styles["Title"]
    ))

    elements.append(Paragraph(
        title,
        styles["Heading2"]
    ))

    elements.append(Paragraph(
        f"Generated on: {datetime.datetime.now().strftime('%d-%m-%Y %H:%M:%S')}",
        styles["Normal"]
    ))

    elements.append(Paragraph(
        f"Total Records: {len(rows)}",
        styles["Normal"]
    ))

    elements.append(Spacer(1, 8 * mm))

    header_style = styles["Normal"].clone("InventoryTableHeader")
    header_style.textColor = colors.HexColor("#1E3A5F")
    header_style.fontName = "Helvetica-Bold"
    table_data = [[
        Paragraph(str(header), header_style)
        for header in headers
    ]]

    for row in rows:
        table_data.append([
            Paragraph(str(value), styles["Normal"])
            for value in row
        ])

    available_width = (
        page_size[0] - document.leftMargin - document.rightMargin
    )

    if report_type == "suppliers":
        proportions = [0.05, 0.18, 0.17, 0.12, 0.20, 0.28]
    else:
        proportions = [0.05, 0.19, 0.13, 0.18, 0.12, 0.13, 0.20]

    column_widths = [
        available_width * proportion
        for proportion in proportions
    ]

    table = Table(
        table_data,
        colWidths = column_widths,
        repeatRows = 1
    )

    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#E6EFFB")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.HexColor("#1E3A5F")),
        ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#CBD5E1")),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 5),
        ("RIGHTPADDING", (0,0), (-1,-1), 5),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F4F7FB")]),
    ]))

    elements.append(table)
    document.build(elements)

    pdf_buffer.seek(0)

    filename = f"{report_type}_report_{datetime.datetime.now():%Y%m%d_%H%M%S}.pdf"

    return send_file(
        pdf_buffer,
        mimetype="application/pdf",
        as_attachment=True,
        download_name = filename
    )

@app.route("/report_selection")
def report_selection():
    if not session.get("role"):
        return redirect(url_for("login"))

    report_type = request.args.get("type")

    #if no report is selected, show the selection page
    if not report_type:
        return render_template("report_selection.html")

    report_queries = {
        "available": (
            "Available Stock Report",
            """
            SELECT p.id, p.product_name, p.category,
                COALESCE(s.supplier_name, 'N/A') AS supplier_name,
                p.price, p.stock_quantity, p.reorder_level
            FROM products p
            LEFT JOIN suppliers s ON p.supplier_id = s.id
            WHERE p.stock_quantity > 0
            ORDER BY p.product_name
            """
        ),

        "low": (
            "Low-Stock Items Report",
            """
            SELECT p.id, p.product_name, p.category,
                COALESCE(s.supplier_name, 'N/A') AS supplier_name,
                p.price, p.stock_quantity, p.reorder_level
            FROM products p
            LEFT JOIN suppliers s ON p.supplier_id = s.id
            WHERE p.stock_quantity > 0
                AND p.stock_quantity <= p.reorder_level
            ORDER BY p.stock_quantity
            """
        ),

        "out": (
            "Out-of-Stock Items Report",
            """
            SELECT p.id, p.product_name, p.category,
                COALESCE(s.supplier_name, 'N/A') AS supplier_name,
                p.price, p.stock_quantity, p.reorder_level
            FROM products p
            LEFT JOIN suppliers s ON p.supplier_id = s.id
            WHERE p.stock_quantity = 0
            ORDER BY p.product_name
            """
        ),

        "suppliers": (
            "Supplier Records Report",
            """
            SELECT id, supplier_name, contact_person,
                   phone, email, address
            FROM suppliers
            ORDER BY supplier_name
            """
        )
    }

    if report_type not in report_queries:
        return "Invalid report type", 400

    report_title, query = report_queries[report_type]
    connection = get_db_connection()

    try:
        records = connection.execute(query).fetchall()

        #Prepare chart data
        chart_labels = []
        stock_data = []
        reorder_data = []
        category_labels = []
        category_counts = []

        if report_type == "available":
            chart_labels = [r["product_name"] for r in records]
            stock_data = [r["stock_quantity"] for r in records]

        elif report_type == "low":
            chart_labels = [r["product_name"] for r in records]
            stock_data = [r["stock_quantity"] for r in records]
            reorder_data = [r["reorder_level"] for r in records]

        elif report_type == "out":
            category_records = connection.execute("""
                SELECT category, COUNT(*) AS total
                FROM products
                WHERE stock_quantity = 0
                GROUP BY category
                ORDER BY category
            """).fetchall()

            category_labels = [
                r["category"] or "Uncategorized"
                for r in category_records
            ]
            category_counts = [
                r["total"] for r in category_records
            ]

        return render_template(
            "report_graph.html",
            report_type = report_type,
            report_title = report_title,
            records = records,
            chart_labels = chart_labels,
            stock_data = stock_data,
            reorder_data = reorder_data,
            category_labels = category_labels,
            category_counts = category_counts,
        )

    finally:
        connection.close()













#================
#run application
#---------------------

import operations
import access
operations.migrate()
operations.install(app, stock_overview)
access.install(app, ADMIN_EMAIL, ADMIN_PASSWORD)
import local_ai
local_ai.install(app)

@app.context_processor
def store_context():
    if not session.get('role'):
        return dict(unread_notifications=0,home_endpoint='login')
    count = operations.read("""SELECT COUNT(*) n FROM notifications n
        WHERE audience IN ('all',?) AND NOT EXISTS
        (SELECT 1 FROM notification_reads r WHERE r.notification_id=n.id AND r.user_key=?)""",
        (session['role'],operations.user_key()),True)['n']
    return dict(unread_notifications=count,home_endpoint={'Admin':'dashboard','Warehouse Staff':'warehouse_dashboard','Sales Staff':'sales_dashboard'}[session['role']])

if __name__ == "__main__":
    create_database()
    app.run(debug=True)