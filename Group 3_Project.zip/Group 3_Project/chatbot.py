import os
import re
import sqlite3

from flask import Blueprint, render_template, request, jsonify, current_app

# Create Flask Blueprint
chatbot_bp = Blueprint("chatbot", __name__)

# Locate inventory.db in the same folder as chatbot.py
DATABASE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "inventory.db"
)

def get_db_connection():
    from database import get_db_connection as connect
    return connect()

def get_all_products():
    """Retrieve products and their supplier information."""
    connection = get_db_connection()

    try:
        products = connection.execute("""
            SELECT
                p.id,
                p.product_name,
                p.category,
                p.price,
                p.stock_quantity,
                p.reorder_level,
                p.description,
                s.supplier_name
            FROM products AS p
            LEFT JOIN suppliers AS s
                ON CAST(p.supplier_id AS INTEGER) = s.id
            ORDER BY p.product_name
        """).fetchall()

        return [dict(product) for product in products]
    finally:
        connection.close()

def format_product(product):
    """Format one product as a readable chatbot response."""
    price = product["price"]
    price_text = (
        f"RM {float(price):.2f}"
        if price is not None
        else "Not available"
    )

    supplier = product.get("supplier_name") or "Not available"
    category = product.get("category") or "Not specified"
    description = product.get("description") or "No description"

    return (
        f"Product: {product['product_name']}\n"
        f"Category: {category}\n"
        f"Price: {price_text}\n"
        f"Stock quantity: {product['stock_quantity']}\n"
        f"Reorder level: {product['reorder_level']}\n"
        f"Supplier: {supplier}\n"
        f"Description: {description}"
    )

def find_matching_products(question, products):
    """Find products whose names match the user's question."""
    stop_words = {
        "what", "is", "the", "price", "of", "how", "many",
        "much", "stock", "quantity", "available", "for",
        "product", "products", "show", "me", "find", "search",
        "details", "information", "about", "supplier", "who",
        "supplies", "does", "have", "in", "please", "tell",
        "give", "can", "you", "check", "are", "there"
    }

    words = re.findall(r"[a-zA-Z0-9]+", question.lower())
    keywords = [word for word in words if word not in stop_words]

    matches = []

    for product in products:
        name = (product["product_name"] or "").lower()

        if name and name in question.lower():
            matches.append(product)

    #If a full product name was not found, match keywords.
    if not matches and keywords:
        for product in products:
            name_words = re.findall(
                r"[a-zA-Z0-9]+",
                (product["product_name"] or "").lower()
            )

            if any(keyword in name_words for keyword in keywords):
                matches.append(product)

    return matches

def answer_question(question):
    """Apply predefined rules to answer inventory questions."""
    question_lower = question.lower().strip()
    products = get_all_products()

    # Rule 1: Greeting
    if re.search(r"\b(hi|hello|hey|good morning|good afternoon)\b",
                 question_lower):
        return (
            "Hello! I am your Inventory Assistant.\n\n"
            "You can ask me about product prices, available stock, "
            "low-stock products, categories, or suppliers."
        )

    # Rule 2: Help
    if any(phrase in question_lower for phrase in [
        "what can you do", "help", "what can i ask",
        "how can you help"
    ]):
        return (
            "I can help you with:\n"
            "1. Show all products\n"
            "2. Find low-stock products\n"
            "3. Show product categories\n"
            "4. Check a product's price\n"
            "5. Check available stock\n"
            "6. Find supplier information\n"
            "7. Search for a product"
        )

    # Rule 3: Low-stock products
    if any(phrase in question_lower for phrase in [
        "low stock", "low-stock", "below reorder",
        "need restock", "need to restock", "reorder"
    ]):
        low_stock = [
            p for p in products
            if p ["stock_quantity"] is not None
            and p["reorder_level"] is not None
            and p["stock_quantity"] <= p["reorder_level"]
        ]

        if not low_stock:
            return "There are no low-stock products currently."

        lines = ["Low-stock products:\n"]

        for product in low_stock:
            lines.append(
                f"- {product['product_name']}: "
                f"{product['stock_quantity']} units available"
                f"(reorder level: {product['reorder_level']})"
            )

        return "\n".join(lines)

    # Rule 4: Product categories
    if "categor" in question_lower:
        categories = sorted({
            p["category"].strip()
            for p in products
            if p["category"] and p["category"].strip()
        })

        if not categories:
            return "No product categories were found."

        return "Available product categories:\n" + "\n".join(
            f"- {category}" for category in categories
        )

    # Rule 5: Show all products
    if any(phrase in question_lower for phrase in [
        "show all products", "list all products",
        "all products", "display products",
        "show products", "list products"
    ]):
        if not products:
            return "There are no products in the inventory."

        lines = ["Products in the inventory:\n"]

        for product in products:
            price = product["price"]
            price_text = (
                f"RM {float(price):.2f}"
                if price is not None
                else "Price available"
            )

            lines.append(
                f"- {product['product_name']} | "
                f"Price: {price_text} | "
                f"Stock: {product['stock_quantity']}"
            )

        return "\n".join(lines)

    # Rule 6: Count products
    if any(phrase in question_lower for phrase in [
        "how many products", "total products",
        "number of products", "product count"
    ]):
        return f"There are {len(products)} products in the inventory."

    # Rule 7: Search for matching products
    matches = find_matching_products(question_lower, products)

    if not matches:
        return (
            "I could not find a matching product in the inventory. "
            "Please check the product name or try another question."
        )

    # Rule 8: Product price
    if any(word in question_lower for word in [
        "price", "cost", "how much"
    ]):
        lines = ["Product price information:\n"]

        for product in matches:
            price = product["price"]
            price_text = (
                f"RM {float(price):.2f}"
                if price is not None
                else "Price available"
            )
            lines.append(f"- {product['product_name']}: {price_text}")

        return "\n".join(lines)

    # Rule 9: Stock quantity
    if any(word in question_lower for word in [
        "stock", "quantity", "available", "units", "left"
    ]):
        lines = ["Product stock information:\n"]

        for product in matches:
            lines.append(
                f"- {product['product_name']}: "
                f"{product['stock_quantity']} units available "
                f"(reorder level: {product['reorder_level']})"
            )

        return "\n".join(lines)

    # Rule 10: Supplier information
    if any(word in question_lower for word in [
        "supplier", "suppliers", "supplied by"
    ]):
        lines = ["Supplier information:\n"]

        for product in matches:
            supplier = product.get("supplier_name") or "Not available"
            lines.append(
                f"- {product['product_name']}: {supplier}"
            )
        return "\n".join(lines)

    # Rule 11: Product details
    if any(word in question_lower for word in [
        "detail", "description", "information", "tell me about"
    ]):
        return "\n\n".join(format_product(p) for p in matches)

    # Rule 12: General matching product question
    return "\n\n".join(format_product(p) for p in matches)

@chatbot_bp.route("/chatbot")
def chatbot_page():
    """Display the chatbot page."""
    return render_template("chatbot.html")

@chatbot_bp.route("/chatbot/ask", methods=["POST"])
def ask_chatbot():
    """Receive a question and return a rule-based answer."""
    try:
        data = request.get_json(silent=True) or {}
        question = data.get("message", "")

        if not isinstance(question, str):
            return jsonify({
                "reply": "Please enter a valid text question."
            }), 400

        question = question.strip()

        if not question:
            return jsonify({
                "reply": "Please enter a question."
            }), 400

        if len(question) > 1000:
            return jsonify({
                "reply": "Please keep your question under 1000 characters."
            }), 400

        reply = answer_question(question)

        return jsonify({"reply": reply})

    except sqlite3.Error:
        current_app.logger.exception("Inventory database error")

        return jsonify({
            "reply": (
                "Unable to retrieve inventory information. "
                "Please check your database."
            )
        }), 500

    except Exception:
        current_app.logger.exception("Unexpected chatbot error")

        return jsonify({
            "reply": "Sorry, something went wrong. Please try again."
        }), 500





