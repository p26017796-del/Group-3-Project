import sqlite3
from pathlib import Path

DATABASE = str(Path(__file__).resolve().with_name("inventory.db"))

def create_database():
    try:
        connection = connect_database(DATABASE)
        print("Database connection successfully.")

        query="""
        CREATE TABLE IF NOT EXISTS users (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           name TEXT NOT NULL,
           email TEXT NOT NULL,
           password TEXT NOT NULL,
           role TEXT NOT NULL
        )
        """

        connection.execute(query)

        suppliers_query="""
        CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        supplier_name TEXT NOT NULL,
        contact_person TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT NOT NULL,
        address TEXT NOT NULL)
        """

        connection.execute(suppliers_query)

        product_query="""
        CREATE TABLE IF NOT EXISTS products (
               id INTEGER PRIMARY KEY AUTOINCREMENT,
               product_name TEXT NOT NULL,
               category TEXT NOT NULL,
               supplier_id INTEGER NOT NULL,
               price REAL NOT NULL,
               stock_quantity INTEGER NOT NULL DEFAULT 0,
               reorder_level INTEGER NOT NULL DEFAULT 10,
               description TEXT,
               
               FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
        )"""
        connection.execute(product_query)

        stock_adjustment_query = """
            CREATE TABLE IF NOT EXISTS stock_adjustments_request (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                warehouse_user_id INTEGER NOT NULL,
                current_quantity INTEGER NOT NULL,
                actual_quantity INTEGER NOT NULL,
                adjustment_quantity INTEGER NOT NULL,
                reason TEXT NOT NULL,
                remarks TEXT,
                status TEXT NOT NULL DEFAULT 'Pending',
                request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id)
                    REFERENCES products(id),
                FOREIGN KEY (warehouse_user_id)
                    REFERENCES users(id)
            )
            """
        connection.execute(stock_adjustment_query)

        customer_query="""
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                email TEXT,
                address TEXT
            )
            """
        connection.execute(customer_query)

        sales_order_query="""
            CREATE TABLE IF NOT EXISTS sales_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                order_date TEXT NOT NULL,
                total_amount REAL NOT NULL,
                payment TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Pending',
                
                FOREIGN KEY (customer_id)
                REFERENCES customers(id)
            )
        """
        connection.execute(sales_order_query)

        sales_order_item_query="""
            CREATE TABLE IF NOT EXISTS sales_order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            subtotal REAL NOT NULL,
            
            FOREIGN KEY (order_id)
                REFERENCES sales_orders(id),
                
            FOREIGN KEY (product_id)
                REFERENCES products(id)
        )
        """
        connection.execute(sales_order_item_query)

        payment_query="""
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                payment_method TEXT NOT NULL,
                amount REAL NOT NULL,
                payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                payment_status TEXT NOT NULL DEFAULT 'Paid',
                
                FOREIGN KEY (order_id)
                    REFERENCES sales_orders(id)
            )
            """
        connection.execute(payment_query)

        connection.commit()
        connection.close()

        print("Database and table created successfully.")

    except sqlite3.Error as error:
        print("Database error:",error)
def get_db_connection():
    connection=connect_database(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


def connect_database(path=None):
    """Open every application connection with SQLite referential checks enabled."""
    connection = sqlite3.connect(DATABASE if path is None else path)
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


FOREIGN_KEY_LINKS = {
    'purchases': [('supplier_id', 'suppliers'), ('product_id', 'products')],
    'stock_movements': [('product_id', 'products')],
    'inventory_returns': [('order_id', 'sales_orders'), ('product_id', 'products')],
    'notification_reads': [('notification_id', 'notifications')],
}


def migrate_foreign_keys():
    """Rebuild legacy child tables atomically, preserving rows, indexes and triggers."""
    c = get_db_connection()
    try:
        c.execute('BEGIN IMMEDIATE')
        for table, links in FOREIGN_KEY_LINKS.items():
            existing = {(r['from'], r['table'], r['to'])
                        for r in c.execute(f'PRAGMA foreign_key_list({table})')}
            missing = [(column, parent) for column, parent in links
                       if (column, parent, 'id') not in existing]
            if not missing:
                continue
            for column, parent in missing:
                if c.execute(f'SELECT 1 FROM "{table}" child LEFT JOIN "{parent}" parent '
                             f'ON child."{column}"=parent.id WHERE child."{column}" IS NOT NULL '
                             'AND parent.id IS NULL LIMIT 1').fetchone():
                    raise sqlite3.IntegrityError(f'Cannot add foreign key: orphan in {table}.{column}')
            original = c.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()[0]
            objects = c.execute("SELECT sql FROM sqlite_master WHERE tbl_name=? AND type IN ('index','trigger') AND sql IS NOT NULL", (table,)).fetchall()
            columns = ','.join('"'+r['name']+'"' for r in c.execute(f'PRAGMA table_info("{table}")'))
            constraints = ''.join(f', FOREIGN KEY ("{column}") REFERENCES "{parent}"(id)' for column, parent in missing)
            body = original[original.index('('):]
            end = body.rfind(')')
            c.execute(f'CREATE TABLE "{table}__fk_new" '+body[:end]+constraints+body[end:])
            c.execute(f'INSERT INTO "{table}__fk_new" ({columns}) SELECT {columns} FROM "{table}"')
            c.execute(f'DROP TABLE "{table}"')
            c.execute(f'ALTER TABLE "{table}__fk_new" RENAME TO "{table}"')
            for obj in objects:
                c.execute(obj[0])
        if c.execute('PRAGMA foreign_key_check').fetchone():
            raise sqlite3.IntegrityError('Foreign key validation failed; migration rolled back')
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()

if __name__ == '__main__':
    create_database()
