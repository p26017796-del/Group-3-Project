"""Small supervised multinomial Naive Bayes models trained on synthetic examples.

No network, generative model or external API. Scores are model probabilities on
this small training vocabulary, not calibrated accuracy estimates.
"""
from collections import Counter
import math
import re


class TextClassifier:
    def __init__(self, examples):
        self.counts={label:Counter(token for phrase in phrases for token in self.tokens(phrase)) for label,phrases in examples.items()}
        self.vocabulary=set().union(*(set(c) for c in self.counts.values()))
        self.totals={label:sum(c.values()) for label,c in self.counts.items()}

    @staticmethod
    def tokens(text):
        return re.findall(r'[a-z]+',text.lower())

    def predict(self,text):
        words=[w for w in self.tokens(text) if w in self.vocabulary]
        if not words:return None,0.0
        scores={label:sum(math.log((counts[w]+1)/(self.totals[label]+len(self.vocabulary))) for w in words) for label,counts in self.counts.items()}
        best=max(scores,key=scores.get)
        denominator=sum(math.exp(score-scores[best]) for score in scores.values())
        return best,1/denominator


INTENTS={
 'price':['what is the price of this product','how much does it cost','tell me the unit price','show selling price','cost per item','how much money for this item','what do you charge for'],
 'stock':['how many units are available','quantity left in stock','check availability of this product','how many do we have remaining','how much inventory remains','is this product on the shelf','remaining units available'],
 'supplier':['who supplies this product','supplier contact for product','who is the vendor','which distributor delivers this item','where do we buy this product','show supplier information'],
 'low':['which items need replenishment','what should we restock','show low stock items','what is running low','products below reorder level','which products need topping up','restock warnings'],
 'out':['show empty shelves','which products have sold out','what is out of stock','zero stock items','unavailable products','items with no stock remaining'],
 'all':['list all products','show the product catalogue','browse our inventory','display everything in the store','what products do we sell','all items list'],
 'categories':['show product categories','what categories are available','list category names','how are products grouped'],
 'count':['how many distinct products','total product count','number of different products','count products in store'],
 'help':['hello','hi there','help me','what can you do','how does this assistant work'],
}
CATEGORIES={
 'Drinks':['mineral bottled sparkling water','cola soda fizzy drink','orange apple fruit juice','iced tea coffee energy sports drink','lemonade beverage coconut water'],
 'Snacks':['potato corn chips crisps','chocolate candy sweets gummy','cookies biscuit crackers','salted nuts popcorn pretzel','cereal snack bar'],
 'Dairy & Eggs':['fresh milk whole skimmed milk','cheddar cheese butter yogurt','cream dairy yoghurt','chicken eggs dozen egg','mozzarella cheese milk'],
 'Bread & Bakery':['bread loaf toast bun','croissant pastry muffin cake','bakery rolls sandwich bread','bagel doughnut baked scone'],
 'Instant Food':['instant noodles ramen cup soup','canned tuna sardines beans','instant porridge rice meal','pasta sauce ready meal','curry noodle packet'],
 'Frozen Food':['frozen ice cream dessert','frozen chicken nuggets dumplings','frozen fish pizza vegetables','frozen fries meat seafood'],
 'Household':['dishwashing liquid detergent cleaner','toilet tissue paper towels','garbage trash bags sponge','laundry detergent bleach','batteries household cleaning'],
 'Personal Care':['toothpaste toothbrush mouthwash','shampoo conditioner hair care','body wash soap deodorant','face cleanser lotion skincare','sanitary pads razor personal hygiene'],
}
intent_model=TextClassifier(INTENTS)
category_model=TextClassifier(CATEGORIES)


def answer(question,products):
    from chatbot import find_matching_products, format_product
    intent,score=intent_model.predict(question)
    if not intent or score<0.30:
        return 'Please ask about product prices, stock, suppliers, low-stock items or categories. This local classifier supports short English inventory questions.',intent,score
    if intent=='help':return 'I use a small local intent classifier and current inventory records. Ask about prices, remaining units, suppliers, or which products need restocking.',intent,score
    if intent=='count':return f'There are {len(products)} distinct products.',intent,score
    if intent=='categories':return 'Categories: '+', '.join(sorted({p['category'] for p in products if p['category']})),intent,score
    if intent in ('low','out','all'):
        selected=[p for p in products if intent=='all' or (intent=='low' and 0<p['stock_quantity']<=p['reorder_level']) or (intent=='out' and p['stock_quantity']<=0)]
        return ('\n'.join(f"{p['product_name']}: {p['stock_quantity']} units" for p in selected) or 'No matching products.'),intent,score
    matches=find_matching_products(question,products)
    if not matches:return 'I could not identify the product. Please include its exact name.',intent,score
    if intent=='price':text='\n'.join(f"{p['product_name']}: RM {p['price']:.2f}" for p in matches)
    elif intent=='supplier':text='\n'.join(f"{p['product_name']}: {p['supplier_name'] or 'No supplier recorded'}" for p in matches)
    elif intent=='stock':text='\n'.join(f"{p['product_name']}: {p['stock_quantity']} units available" for p in matches)
    else:text='\n\n'.join(format_product(p) for p in matches)
    return text,intent,score


def install(app):
    from flask import request,jsonify
    from chatbot import get_all_products
    def ask():
        data=request.get_json(silent=True) or {}
        if not isinstance(data,dict):return jsonify(reply='Send a question object.'),400
        question=data.get('message','')
        if not isinstance(question,str) or not question.strip() or len(question)>1000:return jsonify(reply='Enter a question between 1 and 1,000 characters.'),400
        reply,intent,score=answer(question,get_all_products())
        return jsonify(reply=reply,model='Local Naive Bayes intent classifier',intent=intent,score=round(score,3))
    app.view_functions['chatbot.ask_chatbot']=ask

    @app.route('/product-category-suggestion',methods=['POST'])
    def product_category_suggestion():
        data=request.get_json(silent=True) or {}
        if not isinstance(data,dict):return jsonify(error='Send a product name object.'),400
        name=data.get('name','')
        if not isinstance(name,str) or not name.strip() or len(name)>500:return jsonify(error='Enter a product name first.'),400
        label,score=category_model.predict(name)
        if score<0.20:label=None
        return jsonify(category=label,score=round(score,3),model='Local Naive Bayes classifier',note='Review this suggestion before saving. Model scores are not accuracy guarantees.')
