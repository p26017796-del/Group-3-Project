"""Transactional store workflows. All writes run behind the app's role/CSRF boundary."""
from collections import defaultdict
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from io import BytesIO, StringIO
import csv
import sqlite3
from flask import request, session, render_template, redirect, url_for, flash, abort, send_file
from markupsafe import escape
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import database


def migrate():
    database.create_database()
    c = database.get_db_connection()
    try:
        for table, column, definition in [
            ('products','location',"TEXT NOT NULL DEFAULT 'Main shelf'"),
            ('stock_adjustments_request','movement_version',"INTEGER NOT NULL DEFAULT -1"),
            ('sales_orders','created_by',"TEXT NOT NULL DEFAULT 'Legacy'"),
        ]:
            if column not in {r['name'] for r in c.execute(f'PRAGMA table_info({table})')}:
                c.execute(f'ALTER TABLE {table} ADD COLUMN {column} {definition}')
        c.executescript('''
        CREATE TABLE IF NOT EXISTS stock_movements (
          id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL, product_name TEXT NOT NULL,
          kind TEXT NOT NULL, quantity INTEGER NOT NULL, balance INTEGER NOT NULL,
          reference TEXT NOT NULL, actor TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
          location TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE INDEX IF NOT EXISTS movements_date ON stock_movements(created_at);
        CREATE TABLE IF NOT EXISTS purchases (
          id INTEGER PRIMARY KEY, supplier_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
          quantity INTEGER NOT NULL CHECK(quantity>0), unit_cost REAL NOT NULL CHECK(unit_cost>=0),
          expected_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pending',
          received_quantity INTEGER, damaged_quantity INTEGER, received_at TEXT,
          created_by TEXT NOT NULL, received_by TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS notifications (
          id INTEGER PRIMARY KEY, title TEXT NOT NULL, detail TEXT NOT NULL,
          audience TEXT NOT NULL DEFAULT 'all', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS notification_reads (
          notification_id INTEGER NOT NULL, user_key TEXT NOT NULL,
          PRIMARY KEY(notification_id,user_key));
        CREATE TABLE IF NOT EXISTS inventory_returns (
          id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
          quantity INTEGER NOT NULL CHECK(quantity>0), refund REAL NOT NULL, reason TEXT NOT NULL,
          actor TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS migration_notes (
          key TEXT PRIMARY KEY, detail TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        ''')
        if not c.execute("SELECT 1 FROM migration_notes WHERE key='opening_balances'").fetchone():
            for p in c.execute('SELECT * FROM products').fetchall():
                c.execute('''INSERT INTO stock_movements
                    (product_id,product_name,kind,quantity,balance,reference,actor,note,location)
                    VALUES(?,?,'opening',?,?, 'Migration','System','Opening balance; earlier movement history unavailable',?)''',
                    (p['id'],p['product_name'],p['stock_quantity'],p['stock_quantity'],p['location']))
            c.execute("INSERT INTO migration_notes(key,detail) VALUES('opening_balances','Existing balances preserved; no past transactions invented')")
        c.commit()
    finally:
        c.close()

    database.migrate_foreign_keys()


@contextmanager
def transaction():
    c = database.get_db_connection()
    try:
        c.execute('BEGIN IMMEDIATE')
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def read(query, args=(), one=False):
    c = database.get_db_connection()
    try:
        rows = c.execute(query, args)
        return rows.fetchone() if one else rows.fetchall()
    finally:
        c.close()


def actor():
    return session.get('name', 'Administrator')


def user_key():
    return 'admin' if session.get('role') == 'Admin' else str(session.get('user_id'))


def integer(value, label='Quantity', minimum=1):
    try:
        result = int(str(value))
    except (ValueError, TypeError):
        raise ValueError(f'{label} must be a whole number.')
    if result < minimum or result > 10000000:
        raise ValueError(f'{label} must be between {minimum} and 10,000,000.')
    return result


def money(value):
    try:
        result = Decimal(str(value))
        if not result.is_finite() or result < 0 or result > 100000000:
            raise ValueError('Price must be a non-negative amount below 100,000,000.')
        return float(result.quantize(Decimal('.01')))
    except (InvalidOperation, TypeError):
        raise ValueError('Enter a valid price.')


def notify(c, title, detail, audience='all'):
    c.execute('INSERT INTO notifications(title,detail,audience) VALUES(?,?,?)', (title,detail,audience))


def move(c, product_id, delta, kind, reference, note=''):
    p = c.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    if not p:
        raise ValueError('Product no longer exists.')
    balance = p['stock_quantity'] + delta
    if balance < 0:
        raise ValueError(f"Not enough stock for {p['product_name']}. Available: {p['stock_quantity']}.")
    c.execute('UPDATE products SET stock_quantity=? WHERE id=?', (balance,product_id))
    c.execute('''INSERT INTO stock_movements
        (product_id,product_name,kind,quantity,balance,reference,actor,note,location)
        VALUES(?,?,?,?,?,?,?,?,?)''',
        (product_id,p['product_name'],kind,delta,balance,reference,actor(),note,p['location']))
    if balance <= p['reorder_level']:
        notify(c,'Stock needs attention',f"{p['product_name']}: {balance} units (reorder level {p['reorder_level']}).")
    return balance


def install(app, stock_overview):
    @app.route('/sales-dashboard')
    def sales_dashboard():
        return render_template('dashboard.html', sales_view=True, **stock_overview())

    def create_sale():
        customers = read('SELECT * FROM customers ORDER BY customer_name')
        products = read('SELECT * FROM products WHERE stock_quantity>0 ORDER BY product_name')
        if request.method != 'POST':
            return render_template('create_sales_order.html', customers=customers, products=products)
        try:
            customer_id = integer(request.form.get('customer_id'),'Customer')
            payment = request.form.get('payment','')
            if payment not in ('Cash','Credit Card','Online Banking','E-Wallet'):
                raise ValueError('Select a valid payment method.')
            ids, quantities = request.form.getlist('product_id[]'), request.form.getlist('quantity[]')
            if not ids or len(ids) != len(quantities):
                raise ValueError('Every product needs a quantity.')
            grouped = defaultdict(int)
            for pid, qty in zip(ids, quantities):
                grouped[integer(pid,'Product')] += integer(qty)
            with transaction() as c:
                if not c.execute('SELECT 1 FROM customers WHERE id=?',(customer_id,)).fetchone():
                    raise ValueError('Customer not found.')
                lines, total = [], Decimal('0')
                for pid, qty in grouped.items():
                    p = c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
                    if not p or qty > p['stock_quantity']:
                        raise ValueError('Insufficient stock. Check combined quantities for each product.')
                    subtotal = (Decimal(str(p['price'])) * qty).quantize(Decimal('.01'))
                    total += subtotal
                    lines.append((pid,qty,p['price'],float(subtotal)))
                order_id = c.execute('''INSERT INTO sales_orders
                    (customer_id,order_date,total_amount,payment,status,created_by)
                    VALUES(?,datetime('now'),?,?,'Pending',?)''',
                    (customer_id,float(total),payment,actor())).lastrowid
                c.executemany('INSERT INTO sales_order_items(order_id,product_id,quantity,unit_price,subtotal) VALUES(?,?,?,?,?)',
                              [(order_id,*line) for line in lines])
                notify(c,'New sales order',f'Order #{order_id} is pending confirmation.')
            flash('Order created. Confirm it to reserve stock and record payment.','success')
            return redirect(url_for('order_workflow',order_id=order_id))
        except ValueError as error:
            flash(str(error),'danger')
            return render_template('create_sales_order.html',customers=customers,products=products),400

    app.view_functions['create_sales_order'] = create_sale

    @app.route('/orders/<int:order_id>',methods=['GET','POST'])
    def order_workflow(order_id):
        if request.method == 'POST':
            try:
                action = request.form.get('action')
                role = session['role']
                with transaction() as c:
                    order = c.execute('SELECT * FROM sales_orders WHERE id=?',(order_id,)).fetchone()
                    if not order: abort(404)
                    lines = c.execute('SELECT * FROM sales_order_items WHERE order_id=?',(order_id,)).fetchall()
                    state = order['status']
                    if action == 'confirm' and role in ('Admin','Sales Staff') and state == 'Pending':
                        for item in lines:
                            move(c,item['product_id'],-item['quantity'],'sale',f'SO-{order_id}','Stock reserved at confirmation')
                        c.execute("INSERT INTO payments(order_id,payment_method,amount,payment_status) VALUES(?,?,?,'Paid')",
                                  (order_id,order['payment'],order['total_amount']))
                        next_state = 'Confirmed'
                    elif action == 'dispatch' and role in ('Admin','Warehouse Staff') and state == 'Confirmed':
                        next_state = 'Dispatched'
                        for item in lines:
                            move(c,item['product_id'],0,'dispatch',f'SO-{order_id}',f"Dispatched {item['quantity']} previously reserved units")
                    elif action == 'complete' and role in ('Admin','Sales Staff') and state == 'Dispatched':
                        next_state = 'Completed'
                    elif action == 'cancel' and role in ('Admin','Sales Staff') and state in ('Pending','Confirmed'):
                        if state == 'Confirmed':
                            for item in lines: move(c,item['product_id'],item['quantity'],'cancellation',f'SO-{order_id}')
                            c.execute("UPDATE payments SET payment_status='Refunded' WHERE order_id=?",(order_id,))
                        next_state = 'Cancelled'
                    else:
                        raise ValueError('This action is not allowed for your role or the current order status.')
                    c.execute('UPDATE sales_orders SET status=? WHERE id=?',(next_state,order_id))
                    notify(c,'Order status updated',f'Order #{order_id}: {next_state}.')
                flash(f'Order is now {next_state}.','success')
            except ValueError as error:
                flash(str(error),'danger')
                return redirect(url_for('order_workflow',order_id=order_id))
            return redirect(url_for('order_workflow',order_id=order_id))
        order = read('SELECT so.*,c.customer_name FROM sales_orders so JOIN customers c ON so.customer_id=c.id WHERE so.id=?',(order_id,),True)
        if not order: abort(404)
        items = read('SELECT i.*,p.product_name FROM sales_order_items i LEFT JOIN products p ON p.id=i.product_id WHERE i.order_id=?',(order_id,))
        payments = read('SELECT * FROM payments WHERE order_id=?',(order_id,))
        returns = read('SELECT r.*,p.product_name FROM inventory_returns r LEFT JOIN products p ON p.id=r.product_id WHERE r.order_id=?',(order_id,))
        return render_template('order_workflow.html',order=order,items=items,payments=payments,returns=returns)

    def sales_list():
        customer = request.args.get('customer','').strip()
        state = request.args.get('status','')
        orders = read('''SELECT s.*,c.customer_name FROM sales_orders s JOIN customers c ON c.id=s.customer_id
            WHERE (?='' OR c.customer_name LIKE ?) AND (?='' OR s.status=?) ORDER BY s.id DESC''',
            (customer,'%'+customer+'%',state,state))
        return render_template('orders.html',orders=orders,customer=customer,state=state)
    app.view_functions['sales_orders'] = sales_list
    app.view_functions['view_sales_order'] = lambda order_id: redirect(url_for('order_workflow',order_id=order_id))

    @app.route('/orders/<int:order_id>/return',methods=['POST'])
    def return_sale(order_id):
        try:
            pid = integer(request.form.get('product_id'),'Product')
            qty = integer(request.form.get('quantity'))
            reason = request.form.get('reason','').strip()
            if not reason: raise ValueError('A return reason is required.')
            with transaction() as c:
                order = c.execute('SELECT * FROM sales_orders WHERE id=?',(order_id,)).fetchone()
                if not order or order['status'] not in ('Dispatched','Completed'):
                    raise ValueError('Only dispatched or completed orders can be returned.')
                sold = c.execute('SELECT SUM(quantity) qty, MIN(unit_price) price FROM sales_order_items WHERE order_id=? AND product_id=?',(order_id,pid)).fetchone()
                returned = c.execute('SELECT COALESCE(SUM(quantity),0) FROM inventory_returns WHERE order_id=? AND product_id=?',(order_id,pid)).fetchone()[0]
                if not sold['qty'] or qty > sold['qty']-returned: raise ValueError('Return quantity exceeds the remaining sold quantity.')
                refund = float((Decimal(str(sold['price']))*qty).quantize(Decimal('.01')))
                c.execute('INSERT INTO inventory_returns(order_id,product_id,quantity,refund,reason,actor) VALUES(?,?,?,?,?,?)',(order_id,pid,qty,refund,reason,actor()))
                move(c,pid,qty,'return',f'SO-{order_id}',reason)
                notify(c,'Customer return',f'Order #{order_id}: {qty} units returned; refund RM {refund:.2f}.')
            flash('Return and refund recorded.','success')
        except ValueError as error: flash(str(error),'danger')
        return redirect(url_for('order_workflow',order_id=order_id))

    @app.route('/purchases',methods=['GET','POST'])
    def purchases():
        if request.method == 'POST':
            try:
                pid = integer(request.form.get('product_id'),'Product')
                sid = integer(request.form.get('supplier_id'),'Supplier')
                qty = integer(request.form.get('quantity'))
                cost = money(request.form.get('unit_cost'))
                expected = date.fromisoformat(request.form.get('expected_date','')).isoformat()
                with transaction() as c:
                    if not c.execute('SELECT 1 FROM products WHERE id=?',(pid,)).fetchone() or not c.execute('SELECT 1 FROM suppliers WHERE id=?',(sid,)).fetchone():
                        raise ValueError('Select an existing product and supplier.')
                    po = c.execute('INSERT INTO purchases(supplier_id,product_id,quantity,unit_cost,expected_date,created_by) VALUES(?,?,?,?,?,?)',(sid,pid,qty,cost,expected,actor())).lastrowid
                    notify(c,'Purchase awaiting approval',f'Purchase #{po}: {qty} units.','Admin')
                flash('Purchase request submitted for approval.','success')
            except ValueError as error: flash(str(error),'danger')
            return redirect(url_for('purchases'))
        rows = read('''SELECT po.*,p.product_name,s.supplier_name FROM purchases po JOIN products p ON p.id=po.product_id
            JOIN suppliers s ON s.id=po.supplier_id ORDER BY po.id DESC''')
        return render_template('purchases.html',purchases=rows,products=read('SELECT * FROM products ORDER BY product_name'),suppliers=read('SELECT * FROM suppliers ORDER BY supplier_name'))

    @app.route('/purchases/<int:purchase_id>/action',methods=['POST'])
    def purchase_action(purchase_id):
        try:
            with transaction() as c:
                po = c.execute('SELECT * FROM purchases WHERE id=?',(purchase_id,)).fetchone()
                if not po: abort(404)
                action = request.form.get('action')
                if action in ('approve','reject') and session['role']=='Admin' and po['status']=='Pending':
                    state = 'Approved' if action=='approve' else 'Rejected'
                    c.execute('UPDATE purchases SET status=? WHERE id=?',(state,purchase_id))
                elif action == 'receive' and po['status']=='Approved':
                    received = integer(request.form.get('received_quantity'),'Received quantity',0)
                    damaged = integer(request.form.get('damaged_quantity','0'),'Damaged quantity',0)
                    if received > po['quantity'] or damaged > received: raise ValueError('Received cannot exceed ordered; damaged cannot exceed received.')
                    move(c,po['product_id'],received-damaged,'purchase',f'PO-{purchase_id}',f'Received {received}; damaged {damaged}; ordered {po["quantity"]}')
                    c.execute("UPDATE purchases SET status='Received',received_quantity=?,damaged_quantity=?,received_at=datetime('now'),received_by=? WHERE id=?",(received,damaged,actor(),purchase_id))
                    state = 'Received'
                else: raise ValueError('Purchase action is not allowed in the current state.')
                notify(c,'Purchase updated',f'Purchase #{purchase_id}: {state}.')
            flash('Purchase updated.','success')
        except ValueError as error: flash(str(error),'danger')
        return redirect(url_for('purchases'))

    def inventory():
        if request.method == 'POST':
            try:
                pid = integer(request.form.get('product_id'),'Product')
                qty = integer(request.form.get('adjustment_quantity'))
                kind = request.form.get('adjustment_type')
                if kind not in ('add','reduce'): raise ValueError('Select stock in or stock out.')
                if kind=='add' and session['role']!='Admin': abort(403)
                note = request.form.get('note','').strip()
                if not note: raise ValueError('Record a reason or internal request reference.')
                with transaction() as c:
                    move(c,pid,qty if kind=='add' else -qty,'manual_in' if kind=='add' else 'internal_out','Manual',note)
                    notify(c,'Inventory updated',f'{actor()} recorded a stock movement: {note}.')
                flash('Stock updated and movement recorded.','success')
            except ValueError as error: flash(str(error),'danger')
            return redirect(url_for('manage_inventory'))
        return render_template('stock_operations.html',products=read('SELECT * FROM products ORDER BY product_name'))
    app.view_functions['manage_inventory'] = inventory

    @app.route('/locations',methods=['GET','POST'])
    def locations():
        if request.method=='POST':
            try:
                location = request.form.get('location','').strip()
                if not location or len(location)>120: raise ValueError('Enter a location of 1–120 characters.')
                with transaction() as c:
                    pid = integer(request.form.get('product_id'),'Product')
                    p = c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
                    if not p: raise ValueError('Product not found.')
                    c.execute('UPDATE products SET location=? WHERE id=?',(location,pid))
                    move(c,pid,0,'transfer','Location',f"Moved all {p['stock_quantity']} units from {p['location']} to {location}")
                flash('Shelf location updated and transfer recorded.','success')
            except ValueError as error: flash(str(error),'danger')
            return redirect(url_for('locations'))
        return render_template('locations.html',products=read('SELECT * FROM products ORDER BY product_name'))

    def request_count():
        products=read('SELECT * FROM products ORDER BY product_name')
        if request.method=='POST':
            try:
                pid=integer(request.form.get('product_id'),'Product')
                actual=integer(request.form.get('actual_quantity'),'Actual quantity',0)
                reason=request.form.get('reason','').strip()
                remarks=request.form.get('remarks','').strip()
                if not reason: raise ValueError('Please enter a reason.')
                with transaction() as c:
                    p=c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
                    if not p: raise ValueError('Product not found.')
                    version=c.execute('SELECT COALESCE(MAX(id),0) FROM stock_movements WHERE product_id=?',(pid,)).fetchone()[0]
                    c.execute("""INSERT INTO stock_adjustments_request(product_id,warehouse_user_id,current_quantity,actual_quantity,adjustment_quantity,reason,remarks,movement_version)
                        VALUES(?,?,?,?,?,?,?,?)""",(pid,session['user_id'],p['stock_quantity'],actual,actual-p['stock_quantity'],reason,remarks,version))
                    notify(c,'Stock count awaiting review',f'{actor()} submitted a stock count.','Admin')
                flash('Stock count submitted.','success')
                return redirect(url_for('history'))
            except ValueError as error: flash(str(error),'danger')
        return render_template('stock_adjustment_request.html',products=products)
    app.view_functions['stock_adjustment_request']=request_count

    def approve(request_id):
        try:
            with transaction() as c:
                r = c.execute('SELECT * FROM stock_adjustments_request WHERE id=?',(request_id,)).fetchone()
                if not r or r['status']!='Pending': raise ValueError('Request is missing or already processed.')
                p = c.execute('SELECT * FROM products WHERE id=?',(r['product_id'],)).fetchone()
                version = c.execute('SELECT COALESCE(MAX(id),0) FROM stock_movements WHERE product_id=?',(r['product_id'],)).fetchone()[0]
                if not p or p['stock_quantity']!=r['current_quantity'] or version!=r['movement_version']:
                    raise ValueError('Stock changed after this count. Reject this request and ask staff to recount; no stock was changed.')
                move(c,r['product_id'],r['adjustment_quantity'],'adjustment',f'ADJ-{request_id}',r['reason'])
                c.execute("UPDATE stock_adjustments_request SET status='Approved' WHERE id=?",(request_id,))
                notify(c,'Stock adjustment approved',f'Request #{request_id} approved.','Warehouse Staff')
            flash('Adjustment approved and recorded.','success')
        except ValueError as error: flash(str(error),'danger')
        return redirect(url_for('admin_stock_adjustment_requests'))
    app.view_functions['approve_stock_adjustment'] = approve

    @app.route('/notifications',methods=['GET','POST'])
    def notifications():
        if request.method=='POST':
            with transaction() as c:
                c.execute('''INSERT OR IGNORE INTO notification_reads(notification_id,user_key)
                    SELECT id,? FROM notifications WHERE audience IN ('all',?)''',(user_key(),session['role']))
            return redirect(url_for('notifications'))
        events = read('''SELECT n.*,r.notification_id IS NOT NULL AS is_read FROM notifications n
            LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_key=?
            WHERE n.audience IN ('all',?) ORDER BY n.id DESC LIMIT 100''',(user_key(),session['role']))
        low = read('SELECT * FROM products WHERE stock_quantity<=reorder_level ORDER BY stock_quantity')
        pending = read("SELECT COUNT(*) n FROM stock_adjustments_request WHERE status='Pending'",one=True)['n'] if session['role']!='Sales Staff' else 0
        return render_template('notifications.html',events=events,low=low,pending=pending)

    @app.route('/history')
    def history():
        role = session['role']
        rows = read('SELECT r.*,p.product_name FROM stock_adjustments_request r LEFT JOIN products p ON p.id=r.product_id WHERE warehouse_user_id=? ORDER BY r.id DESC',(session.get('user_id'),)) if role=='Warehouse Staff' else []
        return render_template('adjustment_history.html',rows=rows)

    def reporting_data():
        period = request.args.get('period','month')
        today = datetime.now(timezone.utc).date()
        defaults = {'day':today,'week':today-timedelta(days=today.weekday()),'month':today.replace(day=1)}
        start = date.fromisoformat(request.args.get('start') or defaults.get(period,today.replace(day=1)).isoformat())
        end = date.fromisoformat(request.args.get('end') or today.isoformat())
        if start>end: raise ValueError('Start date must be on or before end date.')
        end_exclusive = end+timedelta(days=1)
        args=(start.isoformat(),end_exclusive.isoformat())
        kind = request.args.get('kind','sales' if session['role']=='Sales Staff' else 'movements')
        allowed = ('sales','trends') if session['role']=='Sales Staff' else ('movements','purchases','sales','suppliers','trends')
        if kind not in allowed: abort(403)
        if kind=='movements':
            headers=['Time (UTC)','Product','Type','Change','Balance','Reference','Operator','Location','Note']
            rows=read('SELECT created_at,product_name,kind,quantity,balance,reference,actor,location,note FROM stock_movements WHERE created_at>=? AND created_at<? ORDER BY id DESC',args)
        elif kind=='purchases':
            headers=['PO','Supplier','Product','Ordered','Received','Damaged','Unit cost (RM)','Status','Created (UTC)']
            rows=read('''SELECT po.id,s.supplier_name,p.product_name,po.quantity,po.received_quantity,po.damaged_quantity,po.unit_cost,po.status,po.created_at
                FROM purchases po JOIN suppliers s ON s.id=po.supplier_id JOIN products p ON p.id=po.product_id
                WHERE po.created_at>=? AND po.created_at<? ORDER BY po.id DESC''',args)
        elif kind=='sales':
            headers=['Order','Customer','Time (UTC)','Status','Order total (RM)','Paid less returns (RM)','Operator']
            rows=read('''SELECT so.id,c.customer_name,so.order_date,so.status,so.total_amount,
                COALESCE((SELECT SUM(amount) FROM payments WHERE order_id=so.id AND payment_status='Paid'),0)
                - COALESCE((SELECT SUM(refund) FROM inventory_returns WHERE order_id=so.id),0),so.created_by
                FROM sales_orders so JOIN customers c ON c.id=so.customer_id
                WHERE so.order_date>=? AND so.order_date<? ORDER BY so.id DESC''',args)
        elif kind=='suppliers':
            headers=['Supplier','Received orders','On time (%)','Accepted units (%)','Received cost (RM)']
            rows=read('''SELECT s.supplier_name,COUNT(*),ROUND(100.0*SUM(CASE WHEN date(po.received_at)<=po.expected_date THEN 1 ELSE 0 END)/COUNT(*),1),
                ROUND(100.0*SUM(po.received_quantity-po.damaged_quantity)/NULLIF(SUM(po.received_quantity),0),1),
                ROUND(SUM((po.received_quantity-po.damaged_quantity)*po.unit_cost),2)
                FROM purchases po JOIN suppliers s ON s.id=po.supplier_id
                WHERE po.status='Received' AND po.received_at>=? AND po.received_at<? GROUP BY s.id ORDER BY s.supplier_name''',args)
        else:
            headers=['Product','Sold units','Returned / cancelled units','Net units','Current stock','Stock at selling price (RM)']
            rows=read('''SELECT p.product_name,
                COALESCE(SUM(CASE WHEN m.kind='sale' THEN -m.quantity ELSE 0 END),0),
                COALESCE(SUM(CASE WHEN m.kind IN ('return','cancellation') THEN m.quantity ELSE 0 END),0),
                COALESCE(SUM(CASE WHEN m.kind='sale' THEN -m.quantity WHEN m.kind IN ('return','cancellation') THEN -m.quantity ELSE 0 END),0),
                p.stock_quantity,ROUND(p.stock_quantity*p.price,2)
                FROM products p LEFT JOIN stock_movements m ON m.product_id=p.id AND m.created_at>=? AND m.created_at<?
                GROUP BY p.id ORDER BY 4 DESC,p.product_name''',args)
        return kind,headers,rows,start,end,period

    @app.route('/activity-reports')
    def activity_reports():
        try: kind,headers,rows,start,end,period=reporting_data()
        except ValueError as error: return render_template('message.html',title='Invalid date range',message=str(error)),400
        chart = read('''SELECT date(created_at) day,SUM(CASE WHEN kind='sale' THEN -quantity WHEN kind IN ('return','cancellation') THEN -quantity ELSE 0 END) units
            FROM stock_movements WHERE created_at>=? AND created_at<? AND kind IN ('sale','return','cancellation') GROUP BY date(created_at) ORDER BY day''',
            (start.isoformat(),(end+timedelta(days=1)).isoformat()))
        maximum=max([abs(r['units']) for r in chart]+[1])
        return render_template('activity_reports.html',kind=kind,headers=headers,rows=rows,start=start,end=end,period=period,chart=chart,maximum=maximum)

    @app.route('/activity-reports/export')
    def export_activity():
        try: kind,headers,rows,start,end,period=reporting_data()
        except ValueError as error: return str(error),400
        if request.args.get('format')=='csv':
            out=StringIO();writer=csv.writer(out)
            def safe(value):
                text='' if value is None else str(value)
                return "'"+text if text.startswith(('=','+','-','@')) else text
            writer.writerow(headers);writer.writerows([[safe(v) for v in r] for r in rows])
            return send_file(BytesIO(('\ufeff'+out.getvalue()).encode()),mimetype='text/csv',as_attachment=True,download_name=f'{kind}-{start}-{end}.csv')
        out=BytesIO();styles=getSampleStyleSheet()
        body=styles['BodyText'];body.fontSize=7;body.leading=9
        cells=[[Paragraph(str(escape(str(v if v is not None else '—'))),body) for v in row] for row in [headers]+[list(r) for r in rows]]
        table=Table(cells,repeatRows=1,colWidths=[760/len(headers)]*len(headers))
        table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8edff')),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#d5d9e7')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        SimpleDocTemplate(out,pagesize=landscape(A4),leftMargin=40,rightMargin=40).build([
            Paragraph(f'CornerShop {kind.title()} Report',styles['Title']),Paragraph(f'{start} to {end} (UTC)',styles['Normal']),Spacer(1,16),table])
        out.seek(0)
        return send_file(out,mimetype='application/pdf',as_attachment=True,download_name=f'{kind}-{start}-{end}.pdf')

    @app.route('/restock-plan')
    def restock_plan():
        rows=read('''SELECT p.*,COALESCE((SELECT SUM(-quantity) FROM stock_movements m
            WHERE m.product_id=p.id AND kind='sale' AND created_at>=datetime('now','-30 days')),0) sold30
            FROM products p ORDER BY p.stock_quantity,p.product_name''')
        recommendations=[]
        for p in rows:
            import math
            target=max(p['reorder_level']*2,math.ceil(p['sold30']/30*14))
            recommendations.append(dict(p)|{'target':target,'suggested':max(0,target-p['stock_quantity'])})
        return render_template('restock_plan.html',rows=recommendations)

    def save_product(id=None):
        product=read('SELECT * FROM products WHERE id=?',(id,),True) if id else None
        if id and not product: abort(404)
        suppliers=read('SELECT * FROM suppliers ORDER BY supplier_name')
        template='edit_product.html' if id else 'add_product.html'
        if request.method=='POST':
            try:
                name=request.form.get('product_name','').strip();category=request.form.get('category','').strip()
                if not name or not category: raise ValueError('Product name and category are required.')
                price=money(request.form.get('price'));qty=integer(request.form.get('stock_quantity','0'),'Stock',0)
                reorder=integer(request.form.get('reorder_level','10'),'Reorder level',0)
                sid=integer(request.form.get('supplier_id'),'Supplier');description=request.form.get('description','')
                with transaction() as c:
                    if not c.execute('SELECT id FROM suppliers WHERE id=?',(sid,)).fetchone(): raise ValueError('Supplier not found.')
                    if id:
                        current=c.execute('SELECT * FROM products WHERE id=?',(id,)).fetchone()
                        if not current: raise ValueError('Product no longer exists.')
                        submitted_stock=integer(request.form.get('original_stock'),'Original stock',0)
                        if current['stock_quantity']!=submitted_stock: raise ValueError('Stock changed while editing. Reload before saving.')
                        c.execute('UPDATE products SET product_name=?,category=?,supplier_id=?,price=?,reorder_level=?,description=? WHERE id=?',(name,category,sid,price,reorder,description,id))
                        if qty!=current['stock_quantity']: move(c,id,qty-current['stock_quantity'],'adjustment','Product edit','Administrator product correction')
                    else:
                        pid=c.execute('''INSERT INTO products(product_name,category,supplier_id,price,stock_quantity,reorder_level,description)
                            VALUES(?,?,?,?,0,?,?)''',(name,category,sid,price,reorder,description)).lastrowid
                        move(c,pid,qty,'opening','New product')
                flash('Product saved.','success')
                return redirect(url_for('manage_products'))
            except ValueError as error:
                flash(str(error),'danger')
                return render_template(template,product=product,suppliers=suppliers),400
        return render_template(template,product=product,suppliers=suppliers)
    app.view_functions['add_product']=save_product
    app.view_functions['edit_product']=save_product

    def delete_record(kind, id):
        definitions={
            'staff':('users','staff_directory',[('stock_adjustments_request','warehouse_user_id')]),
            'customer':('customers','manage_customers',[('sales_orders','customer_id')]),
            'product':('products','manage_products',[('sales_order_items','product_id'),('purchases','product_id'),('stock_adjustments_request','product_id'),('stock_movements','product_id'),('inventory_returns','product_id')]),
            'supplier':('suppliers','manage_suppliers',[('products','supplier_id'),('purchases','supplier_id')])}
        table,destination,refs=definitions[kind]
        record=read(f'SELECT * FROM {table} WHERE id=?',(id,),True)
        if not record: abort(404)
        if request.method!='POST': return render_template('confirm_delete.html',kind=kind,id=id)
        try:
            with transaction() as c:
                if any(c.execute(f'SELECT 1 FROM {t} WHERE {col}=? LIMIT 1',(id,)).fetchone() for t,col in refs):
                    raise ValueError('This record is used by other records. Keep it to preserve history.')
                if kind=='product' and c.execute('SELECT stock_quantity FROM products WHERE id=?',(id,)).fetchone()[0]!=0:
                    raise ValueError('Reduce this product to zero stock with a recorded reason before deleting it.')
                c.execute(f'DELETE FROM {table} WHERE id=?',(id,))
            flash('Record deleted.','success')
        except (ValueError, sqlite3.IntegrityError) as error: flash(str(error),'danger')
        return redirect(url_for(destination))
    app.view_functions['delete_staff']=lambda id:delete_record('staff',id)
    app.view_functions['delete_customer']=lambda id:delete_record('customer',id)
    app.view_functions['delete_product']=lambda id:delete_record('product',id)
    app.view_functions['delete_supplier']=lambda supplier_id:delete_record('supplier',supplier_id)
