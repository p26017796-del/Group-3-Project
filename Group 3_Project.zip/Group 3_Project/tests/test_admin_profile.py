"""Profile persistence and authentication checks using a disposable database."""
import unittest
import test_workflows as workflows
from access import check_password
import operations as ops
import app as a

class AdminProfileTests(unittest.TestCase):
    setUp=workflows.StoreWorkflows.setUp
    tearDown=workflows.StoreWorkflows.tearDown
    login=workflows.StoreWorkflows.login
    post=workflows.StoreWorkflows.post

    def save(self, **overrides):
        data=dict(name='Store Manager',email='manager@example.invalid',current_password='admin123',new_password='',confirm_password='')
        data.update(overrides)
        return self.post('/profile',data)

    def test_save_persists_and_new_login_works(self):
        self.assertIn(b'Save profile',self.client.get('/profile').data)
        self.assertEqual(self.save().status_code,302)
        user=ops.read("SELECT * FROM users WHERE role='Admin'",one=True)
        self.assertEqual(user['name'],'Store Manager')
        self.assertNotEqual(user['password'],'admin123')
        self.assertTrue(check_password(user['password'],'admin123'))
        fresh=a.app.test_client()
        self.assertEqual(self.post('/',dict(email='manager@example.invalid',password='admin123'),fresh).status_code,302)
        self.assertIn(b'Store Manager',fresh.get('/profile').data)
        old=a.app.test_client()
        self.assertEqual(self.post('/',dict(email='admin@gmail.com',password='admin123'),old).status_code,200)
        self.assertEqual(self.client.get('/profile').status_code,200)
        self.assertEqual(self.client.get('/delete-staff/'+str(user['id'])).status_code,302)
        self.assertIsNotNone(ops.read("SELECT * FROM users WHERE role='Admin'",one=True))

    def test_invalid_changes_are_rejected(self):
        for data in [dict(current_password='wrong'),dict(email='sales@example.invalid'),dict(email='bad@'),dict(new_password='short',confirm_password='short'),dict(new_password='newpass123',confirm_password='different')]:
            self.assertEqual(self.save(**data).status_code,200)
            self.assertIsNone(ops.read("SELECT * FROM users WHERE role='Admin'",one=True))

    def test_password_change_invalidates_other_sessions(self):
        other=a.app.test_client();self.login(client=other)
        self.assertEqual(self.save(new_password='newpass123',confirm_password='newpass123').status_code,302)
        self.assertEqual(other.get('/profile').status_code,302)
        fresh=a.app.test_client()
        self.assertEqual(self.post('/',dict(email='manager@example.invalid',password='admin123'),fresh).status_code,200)
        self.assertEqual(self.post('/',dict(email='manager@example.invalid',password='newpass123'),fresh).status_code,302)

    def test_staff_profile_still_works(self):
        self.login('Sales Staff')
        self.assertEqual(self.save(name='Sales Person',email='sales@example.invalid',current_password='').status_code,302)
        self.assertIn(b'Sales Person',self.client.get('/profile').data)
        self.assertEqual(self.save(email='admin@gmail.com',current_password='testpass123').status_code,200)
