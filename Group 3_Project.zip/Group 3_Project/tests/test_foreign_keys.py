import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import database
import operations


class ForeignKeys(unittest.TestCase):
    def test_migration_preserves_rows_and_enforces_all_links(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(database, 'DATABASE', str(Path(temp)/'test.db')):
            operations.migrate()
            c = database.get_db_connection()
            self.assertEqual(c.execute('PRAGMA foreign_keys').fetchone()[0], 1)
            for table, links in database.FOREIGN_KEY_LINKS.items():
                keys = {(r['from'], r['table']) for r in c.execute(f'PRAGMA foreign_key_list({table})')}
                self.assertTrue(set(links).issubset(keys))
            c.execute("INSERT INTO suppliers VALUES(1,'Supplier','Contact','123','a@b','Address')")
            c.execute("INSERT INTO products(id,product_name,category,supplier_id,price) VALUES(1,'Item','Food',1,2)")
            c.execute("INSERT INTO purchases(id,supplier_id,product_id,quantity,unit_cost,expected_date,created_by) VALUES(1,1,1,3,2,'2026-11-25','Admin')")
            c.commit()
            for table, column, parent in [('purchases','supplier_id','suppliers'),('purchases','product_id','products')]:
                with self.assertRaises(sqlite3.IntegrityError):
                    c.execute(f'UPDATE {table} SET {column}=999 WHERE id=1')
                c.rollback()
                with self.assertRaises(sqlite3.IntegrityError):
                    c.execute(f'DELETE FROM {parent} WHERE id=1')
                c.rollback()
            before = tuple(c.execute('SELECT * FROM purchases').fetchone())
            # Recreate a legacy child table without its foreign keys.
            c.execute('PRAGMA foreign_keys=OFF')
            c.execute('CREATE TABLE legacy AS SELECT * FROM purchases')
            c.execute('DROP TABLE purchases')
            c.execute('ALTER TABLE legacy RENAME TO purchases')
            c.commit(); c.close()
            database.migrate_foreign_keys()
            database.migrate_foreign_keys()
            c=database.get_db_connection()
            self.assertEqual(tuple(c.execute('SELECT * FROM purchases').fetchone()),before)
            self.assertEqual(c.execute('PRAGMA foreign_key_check').fetchall(),[])
            c.close()

    def test_orphan_blocks_migration_without_losing_data(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(database, 'DATABASE', str(Path(temp)/'test.db')):
            operations.migrate()
            c=sqlite3.connect(database.DATABASE)
            c.execute('DROP TABLE purchases')
            c.execute('CREATE TABLE purchases(id INTEGER PRIMARY KEY,supplier_id INTEGER,product_id INTEGER)')
            c.execute('INSERT INTO purchases VALUES(1,999,999)')
            c.commit();c.close()
            with self.assertRaises(sqlite3.IntegrityError):
                database.migrate_foreign_keys()
            c=database.get_db_connection()
            self.assertEqual(tuple(c.execute('SELECT * FROM purchases').fetchone()),(1,999,999))
            self.assertEqual(c.execute('PRAGMA foreign_key_list(purchases)').fetchall(),[])
            c.close()
