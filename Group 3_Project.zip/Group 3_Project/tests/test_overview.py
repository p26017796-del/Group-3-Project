"""Dashboard behavior with a separate disposable database; never changes store data."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import app as application
import database
import operations
from access import stamp


class OverviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db_patch = patch.object(database, 'DATABASE', str(Path(self.temp.name) / 'test.db'))
        self.db_patch.start()
        operations.migrate()
        self.client = application.app.test_client()
        self.login()

    def tearDown(self):
        self.db_patch.stop()
        self.temp.cleanup()

    def login(self):
        with self.client.session_transaction() as session:
            session.clear()
            session['admin_logged_in'] = True
            session['role'] = 'Admin'
            session['auth_stamp'] = stamp('admin123')

    def seed(self):
        connection = database.get_db_connection()
        connection.execute("INSERT INTO suppliers VALUES (1,'Local supplier','Contact','123','test@example.invalid','Test')")
        connection.executemany('''INSERT INTO products
            (product_name,category,supplier_id,price,stock_quantity,reorder_level)
            VALUES (?,?,1,2.5,?,?)''', [
            ('Milk', 'Dairy & Eggs', 0, 5),
            ('Chips', 'Snacks', 5, 5),
            ('Water', 'Drinks', 8, 5),
        ])
        connection.commit()
        connection.close()

    def test_thresholds_totals_order_and_filter_independence(self):
        self.seed()
        with application.app.test_request_context('/dashboard?status=low'):
            result = application.stock_overview()
        self.assertEqual(result['stats'], dict(products=3, units=13, low=1, out=1, value=32.5))
        self.assertEqual([p['product_name'] for p in result['products']], ['Chips'])
        for query, expected in [('', ['Milk', 'Chips', 'Water']),
                                ('status=out', ['Milk']), ('status=healthy', ['Water']),
                                ('q=CHIPS&category=Snacks', ['Chips']),
                                ('q=Water&category=Snacks', []),
                                ('q=local', ['Milk', 'Chips', 'Water'])]:
            with application.app.test_request_context('/dashboard?' + query):
                self.assertEqual([p['product_name'] for p in application.stock_overview()['products']], expected)

    def test_empty_and_no_match_states(self):
        self.assertIn(b'Your shelves are ready', self.client.get('/dashboard').data)
        self.seed()
        response = self.client.get('/dashboard?q=unknown')
        self.assertIn(b'No matching products', response.data)
        self.assertIn(b'Showing 0 of 3 products', response.data)

    def test_role_navigation_and_authentication(self):
        self.seed()
        self.assertIn(b'/add-product', self.client.get('/dashboard').data)
        with self.client.session_transaction() as session: session.clear()
        self.assertEqual(self.client.get('/dashboard').status_code, 302)
        self.assertEqual(self.client.get('/staff').status_code, 302)
        connection=database.get_db_connection()
        connection.execute("INSERT INTO users VALUES(1,'Warehouse','w@example.invalid','testpass','Warehouse Staff')")
        connection.commit(); connection.close()
        with self.client.session_transaction() as session:
            session['warehouse_logged_in'] = True
            session['role'] = 'Warehouse Staff'
            session['user_id'] = 1
            session['auth_stamp'] = stamp('testpass')
        page = self.client.get('/warehouse-dashboard')
        self.assertEqual(page.status_code, 200)
        self.assertIn(b'Milk', page.data)
        self.assertIn(b'/manage-suppliers', page.data)
        self.assertNotIn(b'/add-product', page.data)

    def test_dynamic_product_text_is_escaped(self):
        self.seed()
        connection = database.get_db_connection()
        connection.execute("UPDATE products SET product_name = ? WHERE id=1", ('<script>alert(1)</script>',))
        connection.commit(); connection.close()
        page = self.client.get('/dashboard').data
        self.assertNotIn(b'<script>alert(1)</script>', page)
        self.assertIn(b'&lt;script&gt;', page)


if __name__ == '__main__': unittest.main()
