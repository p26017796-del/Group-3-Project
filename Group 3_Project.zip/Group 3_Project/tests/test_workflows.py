import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch
from werkzeug.datastructures import MultiDict
from werkzeug.security import generate_password_hash
import app as a
import database as db
import operations as ops


class StoreWorkflows(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        path=str(Path(self.tmp.name)/'test.db')
        self.patches=[patch.object(db,'DATABASE',path),patch.object(a,'DATABASE',path)]
        for p in self.patches:p.start()
        ops.migrate()
        with ops.transaction() as c:
            c.execute("INSERT INTO suppliers VALUES(1,'Test supplier','Test','123','s@example.invalid','Test')")
            c.execute("INSERT INTO customers VALUES(1,'Test customer','123',NULL,NULL)")
            for uid,name,role in [(1,'warehouse','Warehouse Staff'),(2,'sales','Sales Staff')]:
                c.execute('INSERT INTO users VALUES(?,?,?,?,?)',(uid,name,name+'@example.invalid',generate_password_hash('testpass123'),role))
            c.executemany("INSERT INTO products(id,product_name,category,supplier_id,price,stock_quantity,reorder_level) VALUES(?,?,'Snacks',1,2,10,3)",[(1,'Chips'),(2,'Cookies')])
        self.client=a.app.test_client()
        self.login()

    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.tmp.cleanup()

    def login(self,role='Admin',client=None):
        client=client or self.client
        client.get('/')
        credentials=('admin@gmail.com','admin123') if role=='Admin' else (('warehouse' if role=='Warehouse Staff' else 'sales')+'@example.invalid','testpass123')
        r=self.post('/',{'email':credentials[0],'password':credentials[1]},client)
        self.assertEqual(r.status_code,302)
        return r

    def post(self,path,data=None,client=None):
        client=client or self.client
        with client.session_transaction() as s: token=s.get('_csrf')
        if not token:
            client.get('/')
            with client.session_transaction() as s:token=s['_csrf']
        values=MultiDict(data or {});values.add('_csrf',token)
        return client.post(path,data=values)

    def scalar(self,query,args=()):return ops.read(query,args,True)[0]
    def stock(self,pid=1):return self.scalar('SELECT stock_quantity FROM products WHERE id=?',(pid,))
    def sale(self,ids=(1,),quantities=(2,)):
        data=MultiDict([('customer_id','1'),('payment','Cash')]+[('product_id[]',str(x)) for x in ids]+[('quantity[]',str(x)) for x in quantities])
        return self.post('/admin/create-sales-order',data)
    def order_id(self):return self.scalar('SELECT MAX(id) FROM sales_orders')

    def test_anonymous_and_legacy_flags_cannot_modify_stock(self):
        c=a.app.test_client()
        self.assertEqual(c.get('/admin/inventory').status_code,302)
        self.assertEqual(c.post('/admin/inventory',data={'product_id':1,'adjustment_type':'add','adjustment_quantity':2}).status_code,401)
        with c.session_transaction() as s:s['admin_logged_in']=True
        self.assertEqual(c.get('/admin/inventory').status_code,302)
        self.assertEqual(self.stock(),10)

    def test_csrf_required_and_legitimate_stock_change_logged(self):
        self.assertEqual(self.client.post('/admin/inventory',data={'product_id':1,'adjustment_type':'add','adjustment_quantity':2}).status_code,400)
        self.post('/admin/inventory',{'product_id':1,'adjustment_type':'add','adjustment_quantity':2,'note':'Count correction'})
        self.assertEqual(self.stock(),12)
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM stock_movements WHERE kind='manual_in'"),1)

    def test_role_permissions_and_revoked_accounts(self):
        self.login('Sales Staff')
        self.assertEqual(self.client.get('/admin/inventory').status_code,403)
        self.assertEqual(self.client.get('/staff').status_code,403)
        self.assertEqual(self.client.get('/sales-dashboard').status_code,200)
        self.assertEqual(self.client.get('/activity-reports?kind=suppliers').status_code,403)
        with ops.transaction() as c:c.execute("UPDATE users SET role='Warehouse Staff' WHERE id=2")
        self.assertEqual(self.client.get('/sales-dashboard').status_code,302)

    def test_all_routes_have_explicit_policy(self):
        for rule in a.app.url_map.iter_rules():
            if rule.arguments or rule.endpoint=='static':continue
            c=a.app.test_client();r=c.get(rule.rule)
            if rule.endpoint in ('login','warehouse_login','sales_login'):self.assertEqual(r.status_code,200,rule.rule)
            else:self.assertIn(r.status_code,(302,401,405),rule.rule)

    def test_duplicate_lines_aggregate_and_oversell_rejected(self):
        self.assertEqual(self.sale((1,1),(6,6)).status_code,400)
        self.assertEqual(self.stock(),10)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM sales_orders'),0)
        self.assertEqual(self.sale((1,1),(2,3)).status_code,302)
        self.assertEqual(self.scalar('SELECT quantity FROM sales_order_items'),5)
        self.assertEqual(self.stock(),10)
        self.post(f'/orders/{self.order_id()}',{'action':'confirm'})
        self.assertEqual(self.stock(),5)

    def test_multi_product_payment_once_and_confirmation_idempotent(self):
        self.sale((1,2),(1,1));oid=self.order_id()
        self.post(f'/orders/{oid}',{'action':'confirm'})
        self.post(f'/orders/{oid}',{'action':'confirm'})
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM payments'),1)
        self.assertEqual(self.scalar('SELECT SUM(amount) FROM payments'),4)
        self.assertEqual(self.stock(),9)
        self.assertEqual(self.stock(2),9)

    def test_atomic_confirmation_rolls_back_on_changed_stock(self):
        self.sale((1,2),(5,5));oid=self.order_id()
        with ops.transaction() as c:c.execute('UPDATE products SET stock_quantity=0 WHERE id=2')
        self.post(f'/orders/{oid}',{'action':'confirm'})
        self.assertEqual(self.stock(),10)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM payments'),0)
        self.assertEqual(self.scalar('SELECT status FROM sales_orders'),'Pending')
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM stock_movements WHERE kind='sale'"),0)

    def test_concurrent_confirmation_prevents_overselling(self):
        self.sale((1,),(8,));first=self.order_id();self.sale((1,),(8,));second=self.order_id()
        clients=[a.app.test_client(),a.app.test_client()]
        for c in clients:self.login(client=c)
        with ThreadPoolExecutor(max_workers=2) as pool:
            responses=list(pool.map(lambda pair:self.post(f'/orders/{pair[1]}',{'action':'confirm'},pair[0]),zip(clients,[first,second])))
        self.assertTrue(all(r.status_code==302 for r in responses))
        self.assertEqual(self.stock(),2)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM payments'),1)

    def test_sales_warehouse_full_order_lifecycle_and_return_limit(self):
        self.login('Sales Staff');self.sale();oid=self.order_id()
        self.post(f'/orders/{oid}',{'action':'confirm'})
        self.post(f'/orders/{oid}',{'action':'dispatch'})
        self.assertEqual(self.scalar('SELECT status FROM sales_orders'),'Confirmed')
        self.login('Warehouse Staff');self.post(f'/orders/{oid}',{'action':'dispatch'})
        self.assertEqual(self.stock(),8)
        self.login('Sales Staff');self.post(f'/orders/{oid}',{'action':'complete'})
        self.assertEqual(self.scalar('SELECT status FROM sales_orders'),'Completed')
        self.post(f'/orders/{oid}/return',{'product_id':1,'quantity':1,'reason':'Unopened return'})
        self.assertEqual(self.stock(),9)
        self.post(f'/orders/{oid}/return',{'product_id':1,'quantity':2,'reason':'Too many'})
        self.assertEqual(self.stock(),9)
        self.assertEqual(self.scalar('SELECT SUM(refund) FROM inventory_returns'),2)

    def test_cancel_restores_once(self):
        self.sale();oid=self.order_id();self.post(f'/orders/{oid}',{'action':'confirm'})
        self.post(f'/orders/{oid}',{'action':'cancel'});self.post(f'/orders/{oid}',{'action':'cancel'})
        self.assertEqual(self.stock(),10)
        self.assertEqual(self.scalar('SELECT payment_status FROM payments'),'Refunded')

    def test_purchase_approval_receipt_and_repeat_protection(self):
        self.login('Warehouse Staff')
        self.post('/purchases',{'product_id':1,'supplier_id':1,'quantity':5,'unit_cost':'1.2','expected_date':'2026-11-15'})
        self.post('/purchases/1/action',{'action':'approve'})
        self.assertEqual(self.scalar('SELECT status FROM purchases'),'Pending')
        self.login();self.post('/purchases/1/action',{'action':'approve'})
        self.login('Warehouse Staff')
        self.post('/purchases/1/action',{'action':'receive','received_quantity':5,'damaged_quantity':1})
        self.post('/purchases/1/action',{'action':'receive','received_quantity':5,'damaged_quantity':1})
        self.assertEqual(self.stock(),14)
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM stock_movements WHERE kind='purchase'"),1)
        self.assertIn(b'Test supplier',self.client.get('/activity-reports?kind=suppliers').data)

    def test_stale_count_is_rejected_even_if_quantity_returns_to_original(self):
        self.login('Warehouse Staff');self.post('/stock-adjustment-request',{'product_id':1,'actual_quantity':8,'reason':'Damaged'})
        self.login()
        for kind in ('reduce','add'):self.post('/admin/inventory',{'product_id':1,'adjustment_type':kind,'adjustment_quantity':2,'note':'Movement'})
        self.post('/admin/stock-adjustment/approve/1')
        self.assertEqual(self.stock(),10)
        self.assertEqual(self.scalar('SELECT status FROM stock_adjustments_request'),'Pending')

    def test_fresh_count_approval(self):
        self.login('Warehouse Staff');self.post('/stock-adjustment-request',{'product_id':1,'actual_quantity':8,'reason':'Damaged'})
        self.login();self.post('/admin/stock-adjustment/approve/1')
        self.assertEqual(self.stock(),8)
        self.assertEqual(self.scalar('SELECT status FROM stock_adjustments_request'),'Approved')

    def test_locations_transfer_no_quantity_change(self):
        self.login('Warehouse Staff');self.post('/locations',{'product_id':1,'location':'Aisle A / Shelf 2'})
        self.assertEqual(self.stock(),10)
        self.assertEqual(self.scalar('SELECT location FROM products WHERE id=1'),'Aisle A / Shelf 2')
        self.assertEqual(self.scalar("SELECT quantity FROM stock_movements WHERE kind='transfer'"),0)

    def test_reports_dates_and_exports(self):
        self.post('/admin/inventory',{'product_id':1,'adjustment_type':'add','adjustment_quantity':2,'note':'Audit note'})
        self.assertIn(b'Audit note',self.client.get('/activity-reports?kind=movements').data)
        self.assertNotIn(b'Audit note',self.client.get('/activity-reports?kind=movements&start=2000-01-01&end=2000-01-02').data)
        self.assertEqual(self.client.get('/activity-reports?start=bad').status_code,400)
        for kind in ('movements','purchases','sales','suppliers','trends'):
            r=self.client.get('/activity-reports/export?kind='+kind)
            self.assertEqual(r.status_code,200);self.assertTrue(r.data.startswith(b'%PDF'))
        self.assertEqual(self.client.get('/activity-reports/export?format=csv').mimetype,'text/csv')

    def test_notifications_read_receipt_is_per_user(self):
        with ops.transaction() as c:ops.notify(c,'Shared update','Stock changed')
        self.post('/notifications')
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM notification_reads'),1)
        self.login('Sales Staff')
        self.assertIn(b'Shared update',self.client.get('/notifications').data)
        self.assertIn(b'New',self.client.get('/notifications').data)

    def test_profile_password_and_account_creation_hashes(self):
        self.post('/register-staff',{'name':'New','email':'new@example.invalid','password':'newpass123','confirm_password':'newpass123','role':'Sales Staff'})
        self.assertTrue(self.scalar("SELECT password FROM users WHERE email='new@example.invalid'").startswith('scrypt:'))
        self.login('Sales Staff')
        self.post('/profile',{'name':'Sales Updated','email':'sales@example.invalid','current_password':'testpass123','new_password':'changed123','confirm_password':'changed123'})
        self.assertEqual(self.client.get('/sales-dashboard').status_code,200)
        self.assertEqual(self.scalar('SELECT name FROM users WHERE id=2'),'Sales Updated')

    def test_product_validation_and_logged_stock_edit(self):
        base={'product_name':'New snack','category':'Snacks','supplier_id':1,'price':'2.5','stock_quantity':4,'reorder_level':2,'description':'Test'}
        self.assertEqual(self.post('/add-product',dict(base,price='-1')).status_code,400)
        self.assertEqual(self.post('/add-product',base).status_code,302)
        self.assertEqual(self.scalar("SELECT COUNT(*) FROM stock_movements WHERE kind='opening'"),1)
        self.assertEqual(self.post('/edit-product/1',dict(base,original_stock=10)).status_code,302)
        self.assertEqual(self.stock(),4)
        self.assertEqual(self.post('/edit-product/1',dict(base,original_stock=10)).status_code,400)

    def test_get_delete_is_confirmation_only(self):
        self.assertEqual(self.client.get('/delete_customer/1').status_code,200)
        self.assertEqual(self.client.head('/delete_customer/1').status_code,200)
        self.assertEqual(self.client.head('/delete-staff/1').status_code,200)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM users'),2)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM customers'),1)

    def test_each_role_pages_render(self):
        pages={
          'Admin':['/dashboard','/staff','/add-product','/edit-product/1','/register-staff','/edit-staff/1','/manage-products','/manage_customers','/admin/inventory','/purchases','/locations','/restock-plan','/activity-reports','/notifications','/filtered-reports','/chatbot'],
          'Warehouse Staff':['/warehouse-dashboard','/warehouse-profile','/manage-suppliers','/stock-adjustment-request','/history','/purchases','/locations','/notifications','/admin/sales-orders'],
          'Sales Staff':['/sales-dashboard','/profile','/admin/sales-orders','/admin/create-sales-order','/manage_customers','/activity-reports','/notifications','/chatbot']}
        for role,paths in pages.items():
            self.login(role)
            for path in paths:self.assertEqual(self.client.get(path).status_code,200,(role,path))


    def test_local_ai_intents_categories_and_unknown_input(self):
        import local_ai
        self.assertEqual(local_ai.intent_model.predict('how much does Chips cost')[0],'price')
        self.assertEqual(local_ai.intent_model.predict('how many Chips are left')[0],'stock')
        self.assertEqual(local_ai.category_model.predict('fresh milk')[0],'Dairy & Eggs')
        self.assertEqual(local_ai.category_model.predict('potato chips')[0],'Snacks')
        self.assertIsNone(local_ai.category_model.predict('zzzzz')[0])
        reply,_,_=local_ai.answer('how much does Chips cost',[dict(p)|{'supplier_name':'Test supplier'} for p in ops.read('SELECT * FROM products')])
        self.assertIn('RM 2.00',reply)

    def test_ai_endpoints_are_authenticated_and_csrf_protected(self):
        with self.client.session_transaction() as s:token=s['_csrf']
        headers={'X-CSRF-Token':token}
        response=self.client.post('/product-category-suggestion',json={'name':'potato chips'},headers=headers)
        self.assertEqual(response.json['category'],'Snacks')
        self.assertEqual(self.client.post('/chatbot/ask',json={'message':'hello'}).status_code,400)
        self.assertEqual(self.client.post('/chatbot/ask',json=['bad'],headers=headers).status_code,400)
        reply=self.client.post('/chatbot/ask',json={'message':'how many Chips are left'},headers=headers)
        self.assertIn('10 units',reply.json['reply'])
        self.login('Sales Staff')
        with self.client.session_transaction() as s:token=s['_csrf']
        self.assertEqual(self.client.post('/product-category-suggestion',json={'name':'milk'},headers={'X-CSRF-Token':token}).status_code,403)

    def test_warehouse_cannot_bypass_receiving_approval_with_manual_add(self):
        self.login('Warehouse Staff')
        result=self.post('/admin/inventory',{'product_id':1,'adjustment_type':'add','adjustment_quantity':5,'note':'Bypass'})
        self.assertEqual(result.status_code,403)
        self.assertEqual(self.stock(),10)

if __name__=='__main__':unittest.main()
